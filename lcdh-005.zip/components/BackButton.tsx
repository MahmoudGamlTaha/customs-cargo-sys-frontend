import React from 'react';
import { useNavigate } from 'react-router-dom';
import { BackArrowIcon } from './icons';
import { useLanguage } from '../contexts/LanguageContext';

const BackButton: React.FC = () => {
  const navigate = useNavigate();
  const { t, language } = useLanguage();

  return (
    <button
      onClick={() => navigate(-1)}
      className="flex items-center gap-2 text-brand-primary dark:text-blue-300 font-semibold hover:underline"
      aria-label={t('backButton.label')}
    >
      <div className={`transition-transform duration-300 ease-in-out ${language === 'ar' ? 'rotate-180' : ''}`}>
        <BackArrowIcon />
      </div>
      <span className="hidden sm:inline-block">{t('backButton.text')}</span>
    </button>
  );
};

export default BackButton;