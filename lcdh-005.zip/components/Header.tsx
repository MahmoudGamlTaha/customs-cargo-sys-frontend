import React from 'react';
import { LogoutIcon, ProfileIcon, MenuIcon, SunIcon, MoonIcon } from './icons';
import { useTheme } from '../contexts/ThemeContext';
import { useLanguage } from '../contexts/LanguageContext';


interface HeaderProps {
  onLogout: () => void;
  onMenuClick: () => void;
  userName: string;
}

const Header: React.FC<HeaderProps> = ({ onLogout, onMenuClick, userName }) => {
  const { theme, toggleTheme } = useTheme();
  const { language, setLanguage, t } = useLanguage();
  
  const toggleLanguage = () => {
    const newLang = language === 'ar' ? 'en' : 'ar';
    setLanguage(newLang);
  };
  
  return (
    <header className="flex items-center justify-between px-4 sm:px-6 py-4 bg-white border-b-2 border-gray-200 dark:bg-gray-800 dark:border-gray-700 shrink-0 transition-all duration-300 ease-in-out">
      <div className="flex items-center">
        <button onClick={onMenuClick} className="text-gray-500 focus:outline-none lg:hidden dark:text-gray-400">
          <MenuIcon />
        </button>
        <div className="relative mx-2 hidden md:block">
          <span className="absolute inset-y-0 ltr:left-0 rtl:right-0 flex items-center ltr:pl-3 rtl:pr-3">
            <svg className="w-5 h-5 text-gray-500 dark:text-gray-400" viewBox="0 0 24 24" fill="none">
              <path d="M21 21L15 15M17 10C17 13.866 13.866 17 10 17C6.13401 17 3 13.866 3 10C3 6.13401 6.13401 3 10 3C13.866 3 17 6.13401 17 10Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </span>
          <input className="w-48 lg:w-64 py-2 ltr:pl-10 rtl:pr-10 ltr:pr-4 rtl:pl-4 text-gray-700 bg-white border border-gray-300 rounded-md focus:border-blue-500 focus:outline-none focus:ring dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600" type="text" placeholder={t('header.search')} />
        </div>
      </div>

      <div className="flex items-center">
         <button 
          onClick={toggleTheme} 
          className="p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none"
          aria-label={t('header.toggleTheme')}
        >
          {theme === 'light' ? <MoonIcon /> : <SunIcon />}
        </button>
         <button 
          onClick={toggleLanguage} 
          className="p-2 w-12 text-center font-bold rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none mx-1"
          aria-label={t('header.toggleLanguage')}
        >
          {language === 'ar' ? 'EN' : 'AR'}
        </button>
        <div className="flex items-center ltr:border-l rtl:border-r border-gray-200 dark:border-gray-700 ltr:pl-4 rtl:pr-4 ltr:ml-4 rtl:mr-4">
            <div className='hidden sm:block text-right'>
                <p className="font-bold text-gray-700 dark:text-gray-300 whitespace-nowrap">{t('header.welcome', {name: userName})}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap">{t('roles.member')}</p>
            </div>
            <ProfileIcon />
        </div>
        <button onClick={onLogout} className="flex items-center mx-2 sm:mx-4 text-gray-600 hover:text-brand-primary focus:outline-none dark:text-gray-400 dark:hover:text-white">
          <LogoutIcon />
          <span className="hidden sm:inline-block ltr:ml-2 rtl:mr-2 whitespace-nowrap">{t('header.logout')}</span>
        </button>
      </div>
    </header>
  );
};

export default Header;