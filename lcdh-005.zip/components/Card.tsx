import React from 'react';

// Extend HTMLAttributes to allow passing standard HTML props like 'id'
interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  cardTitle?: string;
  children: React.ReactNode;
  actions?: React.ReactNode;
}

const Card: React.FC<CardProps> = ({ cardTitle, children, className, actions, ...rest }) => {
  return (
    <div {...rest} className={`bg-white dark:bg-gray-800 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300 ${className}`}>
      <div className="p-4 sm:p-6">
        {cardTitle && (
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-bold text-gray-800 dark:text-gray-200 whitespace-nowrap">{cardTitle}</h3>
            {actions && <div className="flex-shrink-0">{actions}</div>}
          </div>
        )}
        <div>{children}</div>
      </div>
    </div>
  );
};

export default Card;