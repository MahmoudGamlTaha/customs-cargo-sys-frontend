

export const translations = {
  ar: {
    backButton: {
      label: "الرجوع",
      text: "الرجوع"
    },
    welcomeScreen: {
      title: "المنصة الرقمية لاتحاد غرف التجارة الليبية",
      disclaimer: "هذا المقترح هو نموذج أولي للتطبيق ولا يجوز مشاركته أو توزيعه حتى يتم اعتماده رسمياً من قبل الطرفين. يخضع لسياسة الخصوصية. جميع الحقوق محفوظة لشركة حلول البرمجة لتقنية المعلومات و الحلول البرمجية",
      agreeCheckbox: "أوافق على سياسة الخصوصية",
      continueButton: "متابعة",
      poweredBy: "مقدم من"
    },
    header: {
      search: "بحث",
      welcome: "مرحباً، {{name}}",
      logout: "خروج",
      toggleTheme: "تغيير السمة",
      toggleLanguage: "تغيير اللغة"
    },
    sidebar: {
      dashboard: "لوحة التحكم",
      applyMembership: "طلب عضوية",
      membershipPending: "عضوية قيد المراجعة",
      reapplyMembership: "إعادة تقديم الطلب",
      documentServices: "الشهادات والتصديقات",
      wallet: "المحفظة",
      payments: "المدفوعات",
      disputeResolution: "فض النزاعات",
      events: "الفعاليات والمعارض",
      support: "الدعم والمساعدة",
      userGuide: "دليل المستخدم",
      elearning: "التدريب الإلكتروني",
      b2bNetworking: "التواصل التجاري",
      profile: "الملف الشخصي",
      managementAndOperations: "الإدارة والتشغيل",
      manageMemberships: "إدارة العضويات",
      manageDocuments: "إدارة المستندات",
      confirmPayments: "إدارة المحفظة",
      account: "الحساب",
      systemManagement: "إدارة النظام",
      manageUsers: "إدارة المستخدمين",
      financialReports: "التقارير المالية",
      biReports: "تقارير ذكاء الأعمال",
      systemSettings: "إعدادات النظام",
      staffSupervision: "إشراف على الموظفين",
      membershipRequests: "طلبات العضوية",
      documentRequests: "طلبات المستندات",
      expand: "توسيع القائمة",
      collapse: "طي القائمة"
    },
    roles: {
        member: 'عضو',
        staff: 'موظف الغرفة',
        admin: 'مدير النظام',
        arbitrator: 'محكم'
    },
    login: {
      title: 'تسجيل الدخول',
      emailLabel: 'البريد الإلكتروني / رقم الهوية',
      passwordLabel: 'كلمة المرور',
      twoFaLabel: 'رمز التحقق (2FA)',
      loginButton: 'تسجيل الدخول',
      forgotPassword: 'نسيت كلمة المرور؟',
      sending: 'جاري الإرسال...',
      linkSent: 'تم إرسال الرابط!',
      createAccount: 'إنشاء حساب جديد',
      invalidCredentials: "بيانات الدخول غير صحيحة. يرجى المحاولة مرة أخرى.",
      signupError: "فشل التسجيل. قد يكون البريد الإلكتروني مستخدماً بالفعل.",
      loginAs: 'تسجيل الدخول كـ (للتجربة):'
    },
    status: {
        Paid: "مدفوعة",
        Pending: "مستحقة",
        RequiresConfirmation: "بانتظار التأكيد",
        New: "جديد",
        InProgress: "قيد المراجعة",
        Completed: "مكتمل",
        Rejected: "مرفوض",
        OnHold: "مجمد",
        PendingPayment: "بانتظار الدفع"
    },
    invoice: {
        newMembershipFee: "رسوم طلب عضوية جديد #{{requestId}}",
        serviceFee: "رسوم خدمة {{serviceType}} #{{requestId}}",
        eventRegistration: "رسوم التسجيل في فعالية: {{eventTitle}}",
    },
    memberDashboard: {
        title: "لوحة تحكم العضو",
        membershipCard: {
            title: "عضوية رجل أعمال",
            subtitle: "Businessman Membership"
        },
        membershipStatusCard: {
            inactiveTitle: "كن عضواً في الاتحاد",
            inactiveText: "انضم إلى مجتمع الأعمال من خلال التقدم بطلب للحصول على عضوية رسمية.",
            inactiveButton: "تقديم طلب العضوية الآن",
            pendingTitle: "طلب العضوية قيد المراجعة",
            pendingText: "لقد استلمنا طلبك، وهو قيد المراجعة من قبل فريقنا. سيتم إعلامك بالقرار قريباً.",
            rejectedTitle: "تم رفض طلب العضوية",
            rejectedText: "للأسف، لم يستوف طلبك السابق المتطلبات. يمكنك مراجعة الشروط وإعادة التقديم.",
            rejectedButton: "إعادة تقديم الطلب"
        },
        completedRequests: "طلبات منجزة",
        inProgressRequests: "طلبات قيد المراجعة",
        latestRequests: {
            title: "أحدث الطلبات",
            serviceType: "نوع الخدمة",
            date: "التاريخ",
            status: "الحالة",
            viewCertificate: "عرض الشهادة",
            noRequests: "لا توجد طلبات حالياً."
        },
        quickLinks: {
            title: "روابط سريعة",
            requestDocument: "طلب تصديق/شهادة",
            manageWallet: "إدارة المحفظة والمدفوعات",
            registerEvent: "التسجيل في فعالية"
        },
        pendingInvoices: {
            title: "فواتير مستحقة (قديمة)",
            invoices: "فواتير",
            goToWallet: "الذهاب للمحفظة"
        }
    },
    staffDashboard: {
        title: "لوحة تحكم الموظف",
        subtitle: "ملخص سريع للمهام التي تتطلب اهتمامك.",
        cards: {
            membershipRequests: "طلبات العضوية الجديدة",
            documentRequests: "طلبات المستندات الجديدة",
            pendingTopUps: "عمليات شحن بانتظار التأكيد",
            cta: "اضغط للمراجعة"
        },
        quickActions: {
            title: "إجراءات سريعة",
            viewReports: "عرض التقارير",
            findMember: "البحث عن عضو"
        }
    },
    adminDashboard: {
        title: "لوحة تحكم الإدارة العليا",
        cards: {
            totalMembers: "إجمالي الأعضاء",
            totalRequests: "إجمالي الطلبات",
            totalWalletFunds: "إجمالي أموال المحافظ",
            activeDisputes: "نزاعات نشطة"
        },
        charts: {
            memberGrowth: "نمو الأعضاء",
            members: "الأعضاء",
            requestsByType: "توزيع الطلبات حسب النوع",
        },
        chambersStats: {
            title: "إحصائيات الغرف التجارية (مثال)",
            chamber: "الغرفة",
            membersCount: "عدد الأعضاء",
            requests: "الطلبات",
            certificatesIssued: "الشهادات الصادرة",
            tripoli: "غرفة طرابلس",
            benghazi: "غرفة بنغازي",
            misrata: "غرفة مصراتة"
        }
    },
    arbitratorDashboard: {
        title: "لوحة تحكم المحكم",
        cardTitle: "النزاعات المعينة",
        table: {
            caseNo: "رقم القضية",
            submittedBy: "مقدم الطلب",
            against: "الخصم",
            submittedAt: "تاريخ التقديم",
            status: "الحالة"
        },
        noDisputes: "لا توجد نزاعات معينة لك حالياً."
    },
    membershipApplication: {
        title: "طلب عضوية جديدة",
        sections: {
            businessInfo: "بيانات النشاط التجاري",
            ownerInfo: "بيانات المالك / المدير المسؤول",
            uploadDocs: "رفع المستندات المطلوبة"
        },
        fields: {
            companyNameAr: "اسم الشركة (بالعربية)",
            companyNameEn: "اسم الشركة (بالإنجليزية)",
            crNumber: "رقم السجل التجاري",
            businessType: "نوع النشاط",
            address: "العنوان",
            phone: "رقم الهاتف",
            ownerName: "الاسم الكامل",
            ownerId: "رقم الهوية / جواز السفر",
            ownerEmail: "البريد الإلكتروني",
            ownerMobile: "رقم الهاتف المحمول"
        },
        upload: {
            click: "انقر للرفع",
            orDrag: "أو قم بسحب وإفلات الملفات هنا",
            fileTypes: "PDF, PNG, JPG, DOCX حتى 10MB"
        },
        docs: {
            cr: "السجل التجاري",
            moa: "عقد التأسيس",
            ownerIdProof: "إثبات هوية المالك"
        },
        submitButton: "ادفع وقدم الطلب",
        status: {
            pendingTitle: "طلبك قيد المراجعة",
            pendingMessage: "طلب عضويتك قيد المراجعة حاليًا. سيتم إعلامك بالقرار قريبًا.",
            approvedTitle: "عضويتك مفعلة",
            approvedMessage: "تهانينا! عضويتك في الاتحاد مفعلة بالكامل.",
            viewCertificate: "عرض شهادة العضوية",
            rejectedTitle: "تم رفض طلبك السابق",
            rejectedMessage: "تم رفض طلب عضويتك السابق. يرجى مراجعة المتطلبات وإعادة تقديم الطلب إذا كنت ترغب في ذلك.",
            inactiveTitle: "كن عضواً في الاتحاد",
            inactiveMessage: "املأ النموذج أدناه لتقديم طلب للحصول على عضوية في الاتحاد العام لغرف التجارة."
        }
    },
    documentServices: {
        title: "طلب شهادة / تصديق",
        newRequest: {
            title: "تقديم طلب جديد",
            selectService: "اختر نوع الخدمة",
            choose: "اختر",
            uploadFiles: "رفع الملفات",
            chooseFile: "اختر ملف",
            orDrag: "أو اسحبه وأفلته هنا",
            fileTypes: "PDF, PNG, JPG up to 10MB",
            fees: "الرسوم",
            submitButton: "ادفع وقدم الطلب"
        },
        certOfOrigin: {
            title: "بيانات شهادة المنشأ",
            consignee: "بيانات المستلم (الاسم والعنوان)",
            transportDetails: "تفاصيل النقل",
            marksAndNumbers: "العلامات والأرقام على الطرود",
            packages: "عدد ونوع الطرود",
            goodsDescription: "وصف البضاعة",
            grossWeight: "الوزن القائم (KG)",
            netWeight: "الوزن الصافي (KG)",
            invoiceNumber: "رقم الفاتورة التجارية",
            invoiceDate: "تاريخ الفاتورة"
        },
        trackRequests: {
            title: "متابعة حالة الطلبات",
            viewCertificate: "عرض الشهادة",
            requestId: "رقم الطلب",
            date: "التاريخ"
        }
    },
    wallet: {
        title: "محفظتي",
        currentBalance: "الرصيد الحالي",
        currency: "د.ل.",
        topUpButton: "شحن الرصيد",
        transferButton: "تحويل أموال",
        historyTitle: "سجل المعاملات",
        table: {
            date: "التاريخ",
            type: "النوع",
            description: "البيان",
            amount: "المبلغ",
            status: "الحالة"
        },
        transactionTypes: {
            "top-up": "شحن رصيد",
            "payment": "دفع خدمة",
            "transfer-in": "استلام تحويل",
            "transfer-out": "إرسال تحويل"
        },
        transactionStatuses: {
            Completed: "مكتملة",
            Pending: "قيد الانتظار",
            Failed: "فاشلة"
        },
        noTransactions: "لا يوجد معاملات لعرضها.",
        insufficientFunds: "رصيد المحفظة غير كافٍ لإتمام هذه العملية. يرجى شحن رصيدك أولاً.",
        insufficientFundsShort: "رصيد غير كافٍ.",
        topUpLink: "اشحن الآن",
        paymentSuccess: "تم خصم رسوم الخدمة من محفظتك بنجاح. طلبك قيد المراجعة الآن.",
        topUpDescription: "شحن المحفظة عبر {{method}}",
        topUpPending: "تم استلام طلب الشحن الخاص بك وهو الآن قيد المراجعة.",
        topUpPage: {
            title: "شحن رصيد المحفظة",
            subtitle: "اختر المبلغ وطريقة الشحن",
            amountLabel: "المبلغ (د.ل.)",
            methodTitle: "اختر طريقة الدفع",
            card: "بطاقة مصرفية",
            sadad: "خدمة سداد",
            transfer: "تحويل مصرفي",
            confirmButton: "تأكيد الشحن"
        },
        transfer: {
            title: "تحويل أموال",
            subtitle: "إرسال الأموال إلى عضو آخر في المنصة",
            recipientLabel: "إلى (اختر المستخدم)",
            amountLabel: "المبلغ (د.ل.)",
            notesLabel: "ملاحظات (اختياري)",
            confirmButton: "تأكيد التحويل",
            userNotFound: "المستخدم المستلم غير موجود.",
            success: "تم تحويل المبلغ بنجاح!",
            outDescription: "تحويل إلى {{name}}. ملاحظات: {{notes}}",
            inDescription: "تحويل من {{name}}. ملاحظات: {{notes}}",
            selectUserPlaceholder: "ابحث عن مستخدم..."
        }
    },
    disputeResolution: {
        title: "التحكيم وفض النزاعات",
        register: {
            button: "تسجيل نزاع تجاري جديد",
            registering: "جاري التسجيل...",
            registered: "تم التسجيل!"
        },
        table: {
            title: "النزاعات المسجلة",
            caseNo: "رقم القضية",
            opponent: "الخصم",
            date: "تاريخ التسجيل",
            status: "الحالة"
        },
        status: {
            under_review: "قيد النظر",
            awaiting_hearing: "تنتظر جلسة استماع",
            judgment_issued: "صدر الحكم"
        }
    },
    disputeDetails: {
        title: "تفاصيل النزاع",
        cardTitle: "تفاصيل القضية",
        placeholder: "هنا سيتم عرض جميع التفاصيل والمستندات والجلسات المتعلقة بالنزاع رقم {{id}}."
    },
    events: {
        title: "الفعاليات والمعارض",
        detailsButton: "التفاصيل والتسجيل",
        notFound: "لم يتم العثور على الفعالية."
    },
    eventDetails: {
        title: "تفاصيل الفعالية",
        date: "التاريخ",
        location: "الموقع",
        fees: "رسوم التسجيل",
        placeholder: "هنا يمكن إضافة المزيد من التفاصيل مثل جدول الأعمال، المتحدثين، وخريطة الموقع.",
        registered: "أنت مسجل في هذه الفعالية",
        registerButton: "تسجيل في الفعالية"
    },
    support: {
        title: "الدعم الفني والاستشارات",
        newTicket: {
            ticketSubject: "عنوان الطلب"
        },
        otherOptions: {
            title: "خيارات الدعم الأخرى",
            submitTicket: "تقديم طلب دعم فني",
            requestConsultation: "طلب استشارة قانونية أو تجارية",
            browseKb: "تصفح قاعدة المعرفة (FAQ)",
            loading: "جاري...",
            done: "تم!"
        },
        trackTickets: {
            title: "متابعة طلبات الدعم",
            status: "الحالة",
            ticket1_title: "مشكلة في تحميل ملفات التصديق",
            status_open: "مفتوح",
            status_solved: "تم الحل",
            ticket2_title: "استفسار عن رسوم التجديد",
            status_in_review: "قيد المراجعة"
        }
    },
    elearning: {
        title: "التدريب والتعلم الإلكتروني",
        myCourses: "دوراتي المسجل بها",
        availableCourses: "استعراض الدورات المتاحة",
        noNewCourses: "لا توجد دورات جديدة متاحة في الوقت الحالي. يرجى التحقق مرة أخرى لاحقًا.",
        course: {
            instructor: "المدرب",
            progress: "التقدم",
            viewCertificate: "عرض الشهادة",
            continue: "متابعة الدورة",
            loading: "جاري التحميل..."
        }
    },
    userProfile: {
      title: "ملف المستخدم",
      accountInfo: {
        title: "بيانات الحساب",
        fullName: "الاسم الكامل",
        email: "البريد الإلكتروني",
        phone: "رقم الهاتف",
        company: "الشركة",
        saveButton: "حفظ التغييرات",
        savingButton: "جاري الحفظ...",
        savedButton: "تم الحفظ!"
      },
      security: {
        title: "الأمان",
        changePassword: "تغيير كلمة المرور",
        changeButton: "تغيير",
        loading: "جاري...",
        done: "تم!",
        twoFa: "التحقق بخطوتين (2FA)",
        status: "الحالة",
        status_active: "نشط",
        disableButton: "تعطيل"
      },
      history: {
        title: "سجل النشاطات",
        item1: "تسجيل الدخول من جهاز جديد.",
        item2: "تقديم طلب شهادة منشأ #D001.",
        item3: "تحديث معلومات الاتصال.",
        item4: "دفع فاتورة تجديد العضوية."
      }
    },
    b2b: {
      title: "التواصل التجاري (B2B)",
      search: {
          placeholder: "ابحث عن شركة أو منتج...",
          button: "بحث",
          searching: "جار البحث..."
      },
      companyCard: {
          contact: "تواصل",
          sending: "جار الإرسال",
          sent: "تم الإرسال"
      },
      marketplace: {
          title: "سوق العروض التجارية",
          noOffers: "لا توجد عروض حالياً."
      }
    },
    companyProfile: {
      title: "ملف الشركة",
      mockCompanyName: "الشركة رقم {{id}}",
      mockSector: "قطاع التجارة العامة",
      placeholder: "هنا يتم عرض معلومات تفصيلية عن الشركة، منتجاتها، خدماتها، ومعلومات الاتصال المتعلقة بالنزاع رقم {{id}}.",
      sendMessage: "إرسال رسالة"
    },
    biReports: {
      title: "تقارير ذكاء الأعمال",
      marketTrends: {
          title: "اتجاهات السوق (استيراد/تصدير)",
          import: "استيراد",
          export: "تصدير"
      },
      memberActivity: {
          title: "توزيع الأعضاء حسب النشاط",
          companyCount: "عدد الشركات"
      }
    },
    certs: {
      download: "تحميل",
      print: "طباعة",
      verify: "للتحقق من صحة الشهادة",
      eSignature: "توقيع إلكتروني معتمد",
      notFound: "لم يتم العثور على الشهادة أو الطلب.",
      chamberPresident: "رئيس مجلس الإدارة",
      membership: {
        title: "شهادة عضوية",
        unionName: "الاتحاد العام لغرف التجارة والصناعة والزراعة - ليبيا",
        certTitle: "شهادة عضوية",
        certSubtitle: "Membership Certificate",
        attestation_1: "يشهد الاتحاد العام لغرف التجارة والصناعة والزراعة بأن السادة:",
        attestation_2: "عضو بالاتحاد ومسجل بسجلاته تحت البيانات التالية:",
        memberId: "رقم العضوية",
        crNo: "رقم السجل التجاري",
        grade: "درجة العضوية",
        activityType: "نوع النشاط",
        activityTypeValue: "تجارة عامة",
        issueDate: "تاريخ الإصدار",
        expiryDate: "تاريخ الانتهاء"
      },
      origin: {
        title: "شهادة منشأ",
        countryNameAr: "دولة ليبيا",
        countryNameEn: "State of Libya",
        certTitleAr: "شهادة منشأ",
        certTitleEn: "CERTIFICATE OF ORIGIN",
        exporter: "المُصدِّر (Exporter)",
        consignee: "المستلم (Consignee)",
        countryOfOrigin: "بلد المنشأ (Country of Origin)",
        transportDetails: "تفاصيل النقل (Transport Details)",
        marksAndNumbers: "العلامات والأرقام (Marks and Numbers)",
        packagesAndDescription: "عدد ونوع الطرود / وصف البضاعة (Number and kind of packages / Description of goods)",
        grossWeight: "الوزن القائم (Gross Weight)",
        netWeight: "الوزن الصافي (Net Weight)",
        invoiceDetails: "تفاصيل الفاتورة (Invoice Details)",
        chamberCertification: "شهادة غرفة التجارة (Chamber of Commerce Certification)",
        chamberAttestation: "تشهد غرفة التجارة والصناعة والزراعة بأن البضاعة الموضحة أعلاه من أصل ليبي.",
        chamberSeal: "ختم وتوقيع الغرفة",
      },
      course: {
          title: "شهادة إتمام دورة تدريبية",
          certTitle: "شهادة إتمام دورة تدريبية",
          certSubtitle: "Certificate of Completion",
          attestation_1: "يشهد مركز التدريب بالاتحاد بأن السيد/السيدة:",
          attestation_2: "قد أتم بنجاح متطلبات الدورة التدريبية بعنوان:",
          instructor: "المدرب المسؤول",
          trainingCenterHead: "مدير مركز التدريب"
      },
      chamberEnrollment: {
        title: "شهادة قيد غرفة",
        certTitle: "شهادة قيد غرفة تجارية",
        attestation_1: "تشهد غرفة التجارة والصناعة والزراعة - {{chamberName}} بأن:",
        company: "الشركة / المؤسسة",
        attestation_2: "مقيدة بالسجل التجاري للغرفة للعام {{year}}.",
        crNo: "رقم السجل التجاري",
        membershipNo: "رقم القيد بالغرفة",
        activity: "النشاط",
        address: "العنوان",
        attestation_3: "أعطيت هذه الشهادة بناءً على طلبه/طلبها دون أدنى مسؤولية على الغرفة تجاه الغير.",
        generalManager: "المدير العام"
      }
    },
    receipt: {
        title: "إيصال دفع",
        subtitle: "Receipt",
        receiptNo: "رقم الإيصال",
        paymentDate: "تاريخ الدفع",
        recipient: "المستلم",
        libya: "ليبيا",
        payer: "الدافع",
        description: "البيان",
        amount: "المبلغ",
        total: "الإجمالي",
        paidStamp: "مدفوع",
        pendingStamp: "بانتظار التأكيد",
        eReceipt: "هذا إيصال إلكتروني ولا يتطلب توقيعاً يدوياً.",
        thankYou: "شكراً لتعاملكم معنا.",
        backToHome: "العودة للرئيسية",
        notFound: "لم يتم العثور على الإيصال."
    },
    review: {
      membership: {
        title: "مراجعة طلب عضوية",
        notFound: "لم يتم العثور على طلب العضوية.",
        detailsTitle: "تفاصيل الطلب",
        companyName: "اسم الشركة",
        applicantName: "اسم مقدم الطلب",
        submissionDate: "تاريخ التقديم",
        currentStatus: "الحالة الحالية",
        attachedDocs: "المستندات المرفقة",
        crDoc: "وثيقة السجل التجاري",
        moaDoc: "وثيقة عقد التأسيس"
      },
      document: {
        title: "مراجعة طلب مستند",
        detailsTitle: "تفاصيل الطلب",
        requestContent: "محتوى الطلب",
        noDetails: "لا توجد تفاصيل إضافية لهذا الطلب.",
        chamberEnrollmentNote: "هذا الطلب لإصدار شهادة قيد غرفة بناءً على بيانات العضوية الحالية للمستخدم.",
        otherNote: "يرجى مراجعة المستند المرفق لاتخاذ القرار.",
        viewAttachment: "عرض المستند المرفق (رابط وهمي)",
      },
      actions: {
        approve: "موافقة",
        reject: "رفض",
        hold: "تعليق"
      }
    },
    staffPages: {
        common: {
            all: "الكل",
            filterByStatus: "تصفية حسب الحالة",
            noRequests: "لا توجد طلبات تطابق هذه التصفية."
        },
        memberships: {
            title: "إدارة طلبات العضوية",
            table: {
                requestId: "رقم الطلب",
                companyName: "اسم الشركة",
                applicant: "مقدم الطلب",
                date: "التاريخ",
                status: "الحالة"
            }
        },
        documents: {
            title: "إدارة طلبات المستندات",
            filter: {
                forReview: "للمراجعة"
            },
            table: {
                requestId: "رقم الطلب",
                serviceType: "نوع الخدمة",
                date: "التاريخ",
                status: "الحالة",
                action: "إجراء",
                noAction: "لا يوجد إجراء",
                viewDetails: "عرض التفاصيل"
            }
        },
        wallet: {
            title: "إدارة المحافظ (شحن الرصيد)",
            cardTitle: "عمليات الشحن بانتظار التأكيد",
            table: {
                transactionId: "رقم العملية",
                user: "المستخدم",
                amount: "المبلغ (د.ل.)",
                date: "التاريخ",
                action: "إجراء"
            },
            confirm: "تأكيد",
            confirmed: "تم التأكيد",
            noTopUps: "لا توجد عمليات شحن بانتظار التأكيد."
        }
    },
    adminPages: {
        users: {
            title: "إدارة المستخدمين",
            searchPlaceholder: "ابحث بالاسم أو البريد الإلكتروني...",
            filters: {
                allRoles: "كل الأدوار",
                allStatuses: "كل الحالات"
            },
            statuses: {
                active: "نشط",
                suspended: "موقوف"
            },
            table: {
                name: "الاسم",
                email: "البريد الإلكتروني",
                company: "الشركة",
                role: "الدور",
                status: "الحالة",
                balance: "رصيد المحفظة",
                membershipStatus: "حالة العضوية",
                action: "إجراء"
            },
            actions: {
                edit: "تعديل",
                suspend: "إيقاف"
            },
            noUsers: "لا يوجد مستخدمون يطابقون البحث."
        },
        financials: {
            title: "التقارير المالية",
            revenueByService: {
                title: "توزيع الإيرادات حسب الخدمة",
                revenue: "الإيرادات (د.ل.)",
                services: {
                    membership_fees: "رسوم العضوية",
                    origin_certificates: "شهادات المنشأ",
                    attestations: "التصديقات",
                    events: "الفعاليات",
                    training: "التدريب"
                }
            },
            monthlyRevenue: {
                title: "نمو الإيرادات الشهرية",
                revenue: "الإيرادات (د.ل.)"
            },
            fullLedger: {
                title: "سجل الحسابات الكامل",
                placeholder: "سيتم هنا عرض خيار لتنزيل سجل الحسابات الكامل كملف Excel أو PDF."
            }
        },
        settings: {
            title: "إعدادات النظام",
            general: {
                title: "إعدادات عامة",
                description: "هذه الصفحة مخصصة لمدير النظام لإدارة الإعدادات الأساسية للمنصة.",
                futureSettingsTitle: "الإعدادات المستقبلية المقترحة:",
                item1: "إدارة رسوم الخدمات والاشتراكات.",
                item2: "تخصيص قوالب الشهادات والإيصالات.",
                item3: "إدارة صلاحيات الموظفين.",
                item4: "إعدادات إشعارات البريد الإلكتروني.",
                item5: "تكامل مع أنظمة خارجية (مثل أنظمة المحاسبة)."
            }
        }
    },
    footer: {
      copyright: "© 2024 - الاتحاد العام لغرف التجارة والصناعة والزراعة. جميع الحقوق محفوظة."
    },
    aiChat: {
        title: "المساعد الذكي",
        initialMessage: "مرحباً! أنا مساعدك الذكي. كيف يمكنني مساعدتك اليوم بخصوص خدمات الاتحاد؟",
        placeholder: "اكتب سؤالك هنا...",
        send: "إرسال",
        sending: "جار الإرسال..."
    },
    userGuide: {
      title: "دليل المستخدم الإرشادي",
      previous: "السابق",
      next: "التالي",
      steps: {
        step1: {
          title: "التسجيل وتسجيل الدخول",
          description: "تعرف على كيفية إنشاء حساب جديد بسهولة أو تسجيل الدخول إلى حسابك الحالي. الخطوة الأولى لبدء رحلتك في المنصة."
        },
        step2: {
          title: "جولة في لوحة التحكم",
          description: "استكشف لوحة التحكم الرئيسية، وافهم كيفية الوصول إلى بطاقة عضويتك الرقمية، واطلع على ملخص لآخر أنشطتك وطلباتك."
        },
        step3: {
          title: "إدارة المحفظة المالية",
          description: "تعلم كيفية شحن رصيد محفظتك، دفع رسوم الخدمات، وتحويل الأموال إلى أعضاء آخرين بسهولة وأمان."
        },
        step4: {
          title: "طلب الخدمات الإلكترونية",
          description: "شرح تفصيلي لخطوات طلب الخدمات مثل شهادة المنشأ أو التصديقات، ومتابعة حالة طلباتك حتى اكتمالها."
        },
        step5: {
          title: "استخدام المساعد الذكي",
          description: "كيفية التفاعل مع المساعد الذكي للحصول على إجابات فورية لاستفساراتك وإرشادك داخل المنصة."
        }
      }
    },
    membership: {
        status: {
            approved: "مقبول",
            pending: "قيد الانتظار",
            rejected: "مرفوض",
            on_hold: "معلق",
            na: "لا يوجد"
        }
    },
    data: {
        jobTitles: {
            chairman: "رئيس مجلس الإدارة"
        },
        grades: {
            excellent: "ممتازة",
            first: "أولى",
            second: "ثانية",
            third: "ثالثة"
        },
        serviceTypes: {
            origin: "شهادة منشأ",
            document_auth: "تصديق مستند",
            other: "خدمات أخرى",
            origin_certificate: "شهادة منشأ",
            invoice_attestation: "تصديق فاتورة",
            contract_attestation: "تصديق عقد",
            chamber_enrollment: "شهادة قيد غرفة"
        },
        events: {
            libya_build: "ليبيا بيلد 2024",
            youth_entrepreneurs: "ملتقى رواد الأعمال الشباب",
            ecommerce_workshop: "ورشة عمل التجارة الإلكترونية",
            description: "وصف افتراضي للفعالية يوضح أهدافها والجمهور المستهدف."
        },
        locations: {
            tripoli: "طرابلس",
            benghazi: "بنغازي",
            misrata: "مصراتة"
        },
        courses: {
            pm_fundamentals: "أساسيات إدارة المشاريع",
            advanced_digital_marketing: "التسويق الرقمي المتقدم",
            negotiation_skills: "مهارات التفاوض للمحترفين"
        },
        months: {
            january: "يناير",
            february: "فبراير",
            march: "مارس",
            april: "أبريل",
            may: "مايو",
            june: "يونيو"
        },
        requestTypes: {
            membership: "عضوية",
            certificates: "شهادات",
            attestations: "تصديقات",
            consultations: "استشارات"
        },
        sectors: {
            all: "كل القطاعات",
            contracting: "مقاولات",
            it: "تقنية المعلومات",
            import_export: "استيراد وتصدير",
            oil_services: "خدمات نفطية"
        },
        activityTypes: {
            general_trading: "تجارة عامة",
            contracting: "مقاولات",
            oil_services: "خدمات نفطية",
            it: "تقنية معلومات",
            foodstuff: "مواد غذائية",
            other: "أخرى"
        },
        opponents: {
            industrial_river: "شركة النهر الصناعي",
            oasis_trading: "مؤسسة الواحة للتجارة",
            new_horizon: "شركة الأفق الجديد"
        },
        companies: {
            modern_building: "شركة البناء الحديث",
            web_solutions: "حلول الويب المبتكرة",
            foodstuff_trading: "تجارة المواد الغذائية",
            advanced_energy: "خدمات الطاقة المتقدمة"
        }
    }
  },
  en: {
    backButton: {
      label: "Go back",
      text: "Back"
    },
    welcomeScreen: {
      title: "Digital Platform for the Libyan Union of Chambers of Commerce",
      disclaimer: "This proposal is a preliminary model of the application and may not be shared or distributed until officially approved by both parties. It is subject to the privacy policy. All rights reserved to Holoul AlBarmgait for Digital Transformation.",
      agreeCheckbox: "I agree to the Privacy Policy",
      continueButton: "Continue",
      poweredBy: "Powered by"
    },
    header: {
      search: "Search",
      welcome: "Welcome, {{name}}",
      logout: "Logout",
      toggleTheme: "Toggle theme",
      toggleLanguage: "Toggle language"
    },
    sidebar: {
      dashboard: "Dashboard",
      applyMembership: "Apply for Membership",
      membershipPending: "Membership Pending",
      reapplyMembership: "Re-apply for Membership",
      documentServices: "Certificates & Attestations",
      wallet: "Wallet",
      payments: "Payments",
      disputeResolution: "Dispute Resolution",
      events: "Events & Exhibitions",
      support: "Support & Help",
      userGuide: "User Guide",
      elearning: "E-Learning",
      b2bNetworking: "B2B Networking",
      profile: "Profile",
      managementAndOperations: "Management & Operations",
      manageMemberships: "Manage Memberships",
      manageDocuments: "Manage Documents",
      confirmPayments: "Wallet Management",
      account: "Account",
      systemManagement: "System Management",
      manageUsers: "Manage Users",
      financialReports: "Financial Reports",
      biReports: "BI Reports",
      systemSettings: "System Settings",
      staffSupervision: "Staff Supervision",
      membershipRequests: "Membership Requests",
      documentRequests: "Document Requests",
      expand: "Expand Menu",
      collapse: "Collapse Menu"
    },
    roles: {
        member: 'Member',
        staff: 'Chamber Staff',
        admin: 'System Administrator',
        arbitrator: 'Arbitrator'
    },
    login: {
      title: 'Login',
      emailLabel: 'Email / ID Number',
      passwordLabel: 'Password',
      twoFaLabel: 'Two-Factor Code (2FA)',
      loginButton: 'Sign In',
      forgotPassword: 'Forgot password?',
      sending: 'Sending...',
      linkSent: 'Link Sent!',
      createAccount: 'Create a new account',
      invalidCredentials: "Invalid credentials. Please try again.",
      signupError: "Signup failed. The email might already be in use.",
      loginAs: 'Login as (for demo):'
    },
    status: {
        Paid: "Paid",
        Pending: "Pending",
        RequiresConfirmation: "Requires Confirmation",
        New: "New",
        InProgress: "In Progress",
        Completed: "Completed",
        Rejected: "Rejected",
        OnHold: "On Hold",
        PendingPayment: "Pending Payment"
    },
    invoice: {
        newMembershipFee: "Fee for new membership application #{{requestId}}",
        serviceFee: "Fee for {{serviceType}} service #{{requestId}}",
        eventRegistration: "Registration fee for event: {{eventTitle}}",
    },
    memberDashboard: {
        title: "Member Dashboard",
        membershipCard: {
            title: "Businessman Membership",
            subtitle: "Businessman Membership"
        },
        membershipStatusCard: {
            inactiveTitle: "Become a Union Member",
            inactiveText: "Join the business community by applying for an official membership.",
            inactiveButton: "Apply for Membership Now",
            pendingTitle: "Membership Application Pending",
            pendingText: "We have received your application, and it's being reviewed by our team. You will be notified of the decision soon.",
            rejectedTitle: "Membership Application Rejected",
            rejectedText: "Unfortunately, your previous application did not meet the requirements. You can review the terms and re-apply.",
            rejectedButton: "Re-apply for Membership"
        },
        completedRequests: "Completed Requests",
        inProgressRequests: "In-Progress Requests",
        latestRequests: {
            title: "Latest Requests",
            serviceType: "Service Type",
            date: "Date",
            status: "Status",
            viewCertificate: "View Certificate",
            noRequests: "No requests found."
        },
        quickLinks: {
            title: "Quick Links",
            requestDocument: "Request Attestation/Certificate",
            manageWallet: "Manage Wallet & Payments",
            registerEvent: "Register for an Event"
        },
        pendingInvoices: {
            title: "Old Pending Invoices",
            invoices: "invoices",
            goToWallet: "Go to Wallet"
        }
    },
    staffDashboard: {
        title: "Staff Dashboard",
        subtitle: "A quick overview of tasks that need your attention.",
        cards: {
            membershipRequests: "New Membership Requests",
            documentRequests: "New Document Requests",
            pendingTopUps: "Top-Ups to Confirm",
            cta: "Click to review"
        },
        quickActions: {
            title: "Quick Actions",
            viewReports: "View Reports",
            findMember: "Find a Member"
        }
    },
    adminDashboard: {
        title: "Senior Management Dashboard",
        cards: {
            totalMembers: "Total Members",
            totalRequests: "Total Requests",
            totalWalletFunds: "Total Wallet Funds",
            activeDisputes: "Active Disputes"
        },
        charts: {
            memberGrowth: "Member Growth",
            members: "Members",
            requestsByType: "Requests Distribution by Type",
        },
        chambersStats: {
            title: "Chambers Statistics (Example)",
            chamber: "Chamber",
            membersCount: "Members",
            requests: "Requests",
            certificatesIssued: "Certificates Issued",
            tripoli: "Tripoli Chamber",
            benghazi: "Benghazi Chamber",
            misrata: "Misrata Chamber"
        }
    },
    arbitratorDashboard: {
        title: "Arbitrator Dashboard",
        cardTitle: "Assigned Disputes",
        table: {
            caseNo: "Case No.",
            submittedBy: "Submitted By",
            against: "Against",
            submittedAt: "Submitted At",
            status: "Status"
        },
        noDisputes: "No disputes are currently assigned to you."
    },
    membershipApplication: {
        title: "New Membership Application",
        sections: {
            businessInfo: "Business Information",
            ownerInfo: "Owner / Manager Information",
            uploadDocs: "Upload Required Documents"
        },
        fields: {
            companyNameAr: "Company Name (Arabic)",
            companyNameEn: "Company Name (English)",
            crNumber: "Commercial Registry No.",
            businessType: "Business Type",
            address: "Address",
            phone: "Phone Number",
            ownerName: "Full Name",
            ownerId: "ID / Passport Number",
            ownerEmail: "Email",
            ownerMobile: "Mobile Number"
        },
        upload: {
            click: "Click to upload",
            orDrag: "or drag and drop",
            fileTypes: "PDF, PNG, JPG, DOCX up to 10MB"
        },
        docs: {
            cr: "Commercial Registry",
            moa: "Memorandum of Association",
            ownerIdProof: "Owner's ID Proof"
        },
        submitButton: "Pay & Submit",
        status: {
            pendingTitle: "Your Application is Pending",
            pendingMessage: "Your membership application is currently under review. You will be notified of the decision soon.",
            approvedTitle: "Your Membership is Active",
            approvedMessage: "Congratulations! Your membership in the Union is fully active.",
            viewCertificate: "View Membership Certificate",
            rejectedTitle: "Your Previous Application was Rejected",
            rejectedMessage: "Your previous membership application was rejected. Please review the requirements and re-submit if you wish.",
            inactiveTitle: "Become a Member of the Union",
            inactiveMessage: "Fill out the form below to apply for membership in the General Union of Chambers of Commerce."
        }
    },
    documentServices: {
        title: "Request Certificate / Attestation",
        newRequest: {
            title: "Submit a New Request",
            selectService: "Select service type",
            choose: "Choose",
            uploadFiles: "Upload Files",
            chooseFile: "Choose a file",
            orDrag: "or drag and drop",
            fileTypes: "PDF, PNG, JPG up to 10MB",
            fees: "Fees",
            submitButton: "Pay & Submit"
        },
        certOfOrigin: {
            title: "Certificate of Origin Data",
            consignee: "Consignee Information (Name & Address)",
            transportDetails: "Transport Details",
            marksAndNumbers: "Marks and Numbers on packages",
            packages: "Number and kind of packages",
            goodsDescription: "Description of goods",
            grossWeight: "Gross Weight (KG)",
            netWeight: "Net Weight (KG)",
            invoiceNumber: "Commercial Invoice Number",
            invoiceDate: "Invoice Date"
        },
        trackRequests: {
            title: "Track Request Status",
            viewCertificate: "View Certificate",
            requestId: "Request ID",
            date: "Date"
        }
    },
    wallet: {
        title: "My Wallet",
        currentBalance: "Current Balance",
        currency: "LYD",
        topUpButton: "Top-up Wallet",
        transferButton: "Transfer Funds",
        historyTitle: "Transaction History",
        table: {
            date: "Date",
            type: "Type",
            description: "Description",
            amount: "Amount",
            status: "Status"
        },
        transactionTypes: {
            "top-up": "Top-up",
            "payment": "Service Payment",
            "transfer-in": "Transfer In",
            "transfer-out": "Transfer Out"
        },
        transactionStatuses: {
            Completed: "Completed",
            Pending: "Pending",
            Failed: "Failed"
        },
        noTransactions: "No transactions to display.",
        insufficientFunds: "Your wallet balance is insufficient for this operation. Please top up your wallet first.",
        insufficientFundsShort: "Insufficient balance.",
        topUpLink: "Top-up now",
        paymentSuccess: "Service fee has been successfully deducted from your wallet. Your request is now under review.",
        topUpDescription: "Wallet top-up via {{method}}",
        topUpPending: "Your top-up request has been received and is now pending confirmation.",
        topUpPage: {
            title: "Top-up Wallet",
            subtitle: "Enter the amount and choose your top-up method",
            amountLabel: "Amount (LYD)",
            methodTitle: "Choose payment method",
            card: "Bank Card",
            sadad: "Sadad Service",
            transfer: "Bank Transfer",
            confirmButton: "Confirm Top-Up"
        },
        transfer: {
            title: "Transfer Funds",
            subtitle: "Send funds to another member on the platform",
            recipientLabel: "To (Select User)",
            amountLabel: "Amount (LYD)",
            notesLabel: "Notes (Optional)",
            confirmButton: "Confirm Transfer",
            userNotFound: "Recipient user not found.",
            success: "Transfer completed successfully!",
            outDescription: "Transfer to {{name}}. Notes: {{notes}}",
            inDescription: "Transfer from {{name}}. Notes: {{notes}}",
            selectUserPlaceholder: "Search for a user..."
        }
    },
    disputeResolution: {
        title: "Arbitration & Dispute Resolution",
        register: {
            button: "Register a New Commercial Dispute",
            registering: "Registering...",
            registered: "Registered!"
        },
        table: {
            title: "Registered Disputes",
            caseNo: "Case No.",
            opponent: "Opponent",
            date: "Registration Date",
            status: "Status"
        },
        status: {
            under_review: "Under Review",
            awaiting_hearing: "Awaiting Hearing",
            judgment_issued: "Judgment Issued"
        }
    },
    disputeDetails: {
        title: "Dispute Details",
        cardTitle: "Case Details",
        placeholder: "All details, documents, and sessions related to dispute #{{id}} will be displayed here."
    },
    events: {
        title: "Events & Exhibitions",
        detailsButton: "Details & Registration",
        notFound: "Event not found."
    },
    eventDetails: {
        title: "Event Details",
        date: "Date",
        location: "Location",
        fees: "Registration Fees",
        placeholder: "More details like the agenda, speakers, and location map can be added here.",
        registered: "You are registered for this event",
        registerButton: "Register for Event"
    },
    support: {
        title: "Support & Consultations",
        newTicket: {
            ticketSubject: "Ticket Subject"
        },
        otherOptions: {
            title: "Other Support Options",
            submitTicket: "Submit a Support Ticket",
            requestConsultation: "Request Legal or Business Consultation",
            browseKb: "Browse Knowledge Base (FAQ)",
            loading: "Loading...",
            done: "Done!"
        },
        trackTickets: {
            title: "Track Support Tickets",
            status: "Status",
            ticket1_title: "Problem uploading attestation files",
            status_open: "Open",
            status_solved: "Solved",
            ticket2_title: "Inquiry about renewal fees",
            status_in_review: "In Review"
        }
    },
    elearning: {
        title: "Training & E-Learning",
        myCourses: "My Enrolled Courses",
        availableCourses: "Browse Available Courses",
        noNewCourses: "No new courses are available at the moment. Please check back later.",
        course: {
            instructor: "Instructor",
            progress: "Progress",
            viewCertificate: "View Certificate",
            continue: "Continue Course",
            loading: "Loading..."
        }
    },
    userProfile: {
      title: "User Profile",
      accountInfo: {
        title: "Account Information",
        fullName: "Full Name",
        email: "Email",
        phone: "Phone Number",
        company: "Company",
        saveButton: "Save Changes",
        savingButton: "Saving...",
        savedButton: "Saved!"
      },
      security: {
        title: "Security",
        changePassword: "Change Password",
        changeButton: "Change",
        loading: "Loading...",
        done: "Done!",
        twoFa: "Two-Factor Authentication (2FA)",
        status: "Status",
        status_active: "Active",
        disableButton: "Disable"
      },
      history: {
        title: "Activity Log",
        item1: "Login from a new device.",
        item2: "Submitted Certificate of Origin request #D001.",
        item3: "Updated contact information.",
        item4: "Paid membership renewal invoice."
      }
    },
    b2b: {
      title: "B2B Networking",
      search: {
          placeholder: "Search for a company or product...",
          button: "Search",
          searching: "Searching..."
      },
      companyCard: {
          contact: "Contact",
          sending: "Sending...",
          sent: "Sent"
      },
      marketplace: {
          title: "Trade Offers Marketplace",
          noOffers: "No offers available currently."
      }
    },
    companyProfile: {
      title: "Company Profile",
      mockCompanyName: "Company #{{id}}",
      mockSector: "General Trading Sector",
      placeholder: "Detailed information about the company, its products, services, and contact info for case #{{id}} would be displayed here.",
      sendMessage: "Send Message"
    },
    biReports: {
      title: "Business Intelligence Reports",
      marketTrends: {
          title: "Market Trends (Import/Export)",
          import: "Import",
          export: "Export"
      },
      memberActivity: {
          title: "Member Distribution by Activity",
          companyCount: "No. of Companies"
      }
    },
    certs: {
      download: "Download",
      print: "Print",
      verify: "To verify this certificate",
      eSignature: "Authorized E-Signature",
      notFound: "Certificate or request not found.",
      chamberPresident: "Chairman of the Board",
      membership: {
        title: "Membership Certificate",
        unionName: "General Union of Chambers of Commerce, Industry and Agriculture - Libya",
        certTitle: "Membership Certificate",
        certSubtitle: "Membership Certificate",
        attestation_1: "The General Union of Chambers of Commerce, Industry and Agriculture certifies that:",
        attestation_2: "is a member of the Union and registered in its records under the following data:",
        memberId: "Membership ID",
        crNo: "Commercial Registry No.",
        grade: "Membership Grade",
        activityType: "Activity Type",
        activityTypeValue: "General Trading",
        issueDate: "Issue Date",
        expiryDate: "Expiry Date"
      },
      origin: {
        title: "Certificate of Origin",
        countryNameAr: "State of Libya",
        countryNameEn: "State of Libya",
        certTitleAr: "Certificate of Origin",
        certTitleEn: "CERTIFICATE OF ORIGIN",
        exporter: "Exporter",
        consignee: "Consignee",
        countryOfOrigin: "Country of Origin",
        transportDetails: "Transport Details",
        marksAndNumbers: "Marks and Numbers",
        packagesAndDescription: "Number and kind of packages / Description of goods",
        grossWeight: "Gross Weight",
        netWeight: "Net Weight",
        invoiceDetails: "Invoice Details",
        chamberCertification: "Chamber of Commerce Certification",
        chamberAttestation: "The Chamber of Commerce, Industry and Agriculture certifies that the goods described above are of Libyan origin.",
        chamberSeal: "Chamber's Seal & Signature",
      },
      course: {
          title: "Course Completion Certificate",
          certTitle: "Certificate of Completion",
          certSubtitle: "Certificate of Completion",
          attestation_1: "The Training Center of the Union certifies that Mr./Mrs.:",
          attestation_2: "has successfully completed the requirements of the training course titled:",
          instructor: "Lead Instructor",
          trainingCenterHead: "Director of Training Center"
      },
      chamberEnrollment: {
        title: "Chamber Enrollment Certificate",
        certTitle: "Chamber of Commerce Enrollment Certificate",
        attestation_1: "The Chamber of Commerce, Industry, and Agriculture - {{chamberName}} certifies that:",
        company: "Company / Establishment",
        attestation_2: "is enrolled in the Chamber's commercial registry for the year {{year}}.",
        crNo: "Commercial Registry No.",
        membershipNo: "Chamber Enrollment No.",
        activity: "Activity",
        address: "Address",
        attestation_3: "This certificate has been issued upon their request without any liability on the Chamber towards third parties.",
        generalManager: "General Manager"
      }
    },
    receipt: {
        title: "Payment Receipt",
        subtitle: "Receipt",
        receiptNo: "Receipt No.",
        paymentDate: "Payment Date",
        recipient: "Recipient",
        libya: "Libya",
        payer: "Payer",
        description: "Description",
        amount: "Amount",
        total: "Total",
        paidStamp: "PAID",
        pendingStamp: "Pending Confirmation",
        eReceipt: "This is an electronic receipt and does not require a manual signature.",
        thankYou: "Thank you for your business.",
        backToHome: "Back to Home",
        notFound: "Receipt not found."
    },
    review: {
      membership: {
        title: "Review Membership Application",
        notFound: "Membership application not found.",
        detailsTitle: "Application Details",
        companyName: "Company Name",
        applicantName: "Applicant Name",
        submissionDate: "Submission Date",
        currentStatus: "Current Status",
        attachedDocs: "Attached Documents",
        crDoc: "Commercial Registry Document",
        moaDoc: "Memorandum of Association Document"
      },
      document: {
        title: "Review Document Request",
        detailsTitle: "Request Details",
        requestContent: "Request Content",
        noDetails: "No additional details for this request.",
        chamberEnrollmentNote: "This is a request for a Chamber Enrollment Certificate based on the user's existing membership profile.",
        otherNote: "Please review the attached document to make a decision.",
        viewAttachment: "View Attached Document (mock link)",
      },
      actions: {
        approve: "Approve",
        reject: "Reject",
        hold: "On Hold"
      }
    },
    staffPages: {
        common: {
            all: "All",
            filterByStatus: "Filter by status",
            noRequests: "No requests match this filter."
        },
        memberships: {
            title: "Manage Membership Requests",
            table: {
                requestId: "Request ID",
                companyName: "Company Name",
                applicant: "Applicant",
                date: "Date",
                status: "Status"
            }
        },
        documents: {
            title: "Manage Document Requests",
            filter: {
                forReview: "For Review"
            },
            table: {
                requestId: "Request ID",
                serviceType: "Service Type",
                date: "Date",
                status: "Status",
                action: "Action",
                noAction: "No action needed",
                viewDetails: "View Details"
            }
        },
        wallet: {
            title: "Wallet Management (Top-ups)",
            cardTitle: "Top-up Transactions Awaiting Confirmation",
            table: {
                transactionId: "Transaction ID",
                user: "User",
                amount: "Amount (LYD)",
                date: "Date",
                action: "Action"
            },
            confirm: "Confirm",
            confirmed: "Confirmed",
            noTopUps: "No top-ups are awaiting confirmation."
        }
    },
    adminPages: {
        users: {
            title: "User Management",
            searchPlaceholder: "Search by name or email...",
            filters: {
                allRoles: "All Roles",
                allStatuses: "All Statuses"
            },
            statuses: {
                active: "Active",
                suspended: "Suspended"
            },
            table: {
                name: "Name",
                email: "Email",
                company: "Company",
                role: "Role",
                status: "Status",
                balance: "Wallet Balance",
                membershipStatus: "Membership Status",
                action: "Action"
            },
            actions: {
                edit: "Edit",
                suspend: "Suspend"
            },
            noUsers: "No users match the search criteria."
        },
        financials: {
            title: "Financial Reports",
            revenueByService: {
                title: "Revenue Distribution by Service",
                revenue: "Revenue (LYD)",
                services: {
                    membership_fees: "Membership Fees",
                    origin_certificates: "Origin Certificates",
                    attestations: "Attestations",
                    events: "Events",
                    training: "Training"
                }
            },
            monthlyRevenue: {
                title: "Monthly Revenue Growth",
                revenue: "Revenue (LYD)"
            },
            fullLedger: {
                title: "Full Ledger",
                placeholder: "An option to download the full accounting ledger as an Excel or PDF file will be available here."
            }
        },
        settings: {
            title: "System Settings",
            general: {
                title: "General Settings",
                description: "This page is for the System Administrator to manage core platform settings.",
                futureSettingsTitle: "Proposed future settings:",
                item1: "Manage service fees and subscriptions.",
                item2: "Customize certificate and receipt templates.",
                item3: "Manage staff permissions and roles.",
                item4: "Email notification settings.",
                item5: "Integrations with external systems (e.g., accounting software)."
            }
        }
    },
    footer: {
      copyright: "© 2024 - General Union of Chambers of Commerce, Industry and Agriculture. All Rights Reserved."
    },
    aiChat: {
        title: "AI Assistant",
        initialMessage: "Hello! I'm your AI assistant. How can I help you today regarding the Union's services?",
        placeholder: "Type your question here...",
        send: "Send",
        sending: "Sending..."
    },
    userGuide: {
      title: "Illustrated User Guide",
      previous: "Previous",
      next: "Next",
      steps: {
        step1: {
          title: "Registration & Login",
          description: "Learn how to easily create a new account or log in to your existing one. The first step to starting your journey on the platform."
        },
        step2: {
          title: "Dashboard Tour",
          description: "Explore the main dashboard, understand how to access your digital membership card, and see a summary of your latest activities and requests."
        },
        step3: {
          title: "Managing Your Wallet",
          description: "Learn how to top up your wallet balance, pay for services, and transfer funds to other members easily and securely."
        },
        step4: {
          title: "Requesting E-Services",
          description: "A detailed explanation of the steps to request services like a Certificate of Origin or attestations, and how to track your requests until completion."
        },
        step5: {
          title: "Using the AI Assistant",
          description: "How to interact with the AI assistant to get instant answers to your inquiries and guidance within the platform."
        }
      }
    },
    membership: {
        status: {
            approved: "Approved",
            pending: "Pending",
            rejected: "Rejected",
            on_hold: "On Hold",
            na: "N/A"
        }
    },
    data: {
        jobTitles: {
            chairman: "Chairman"
        },
        grades: {
            excellent: "Excellent",
            first: "First",
            second: "Second",
            third: "Third"
        },
        serviceTypes: {
            origin: "Certificate of Origin",
            document_auth: "Document Attestation",
            other: "Other Services",
            origin_certificate: "Certificate of Origin",
            invoice_attestation: "Invoice Attestation",
            contract_attestation: "Contract Attestation",
            chamber_enrollment: "Chamber Enrollment Certificate"
        },
        events: {
            libya_build: "Libya Build 2024",
            youth_entrepreneurs: "Youth Entrepreneurs Forum",
            ecommerce_workshop: "E-commerce Workshop",
            description: "A default description for the event, explaining its goals and target audience."
        },
        locations: {
            tripoli: "Tripoli",
            benghazi: "Benghazi",
            misrata: "Misrata"
        },
        courses: {
            pm_fundamentals: "Project Management Fundamentals",
            advanced_digital_marketing: "Advanced Digital Marketing",
            negotiation_skills: "Negotiation Skills for Professionals"
        },
        months: {
            january: "January",
            february: "February",
            march: "March",
            april: "April",
            may: "May",
            june: "June"
        },
        requestTypes: {
            membership: "Membership",
            certificates: "Certificates",
            attestations: "Attestations",
            consultations: "Consultations"
        },
        sectors: {
            all: "All Sectors",
            contracting: "Contracting",
            it: "IT",
            import_export: "Import/Export",
            oil_services: "Oil Services"
        },
        activityTypes: {
            general_trading: "General Trading",
            contracting: "Contracting",
            oil_services: "Oil Services",
            it: "Information Technology",
            foodstuff: "Foodstuff",
            other: "Other"
        },
        opponents: {
            industrial_river: "Industrial River Company",
            oasis_trading: "Oasis Trading Establishment",
            new_horizon: "New Horizon Co."
        },
        companies: {
            modern_building: "Modern Building Company",
            web_solutions: "Innovative Web Solutions",
            foodstuff_trading: "Foodstuff Trading",
            advanced_energy: "Advanced Energy Services"
        }
    }
  }
};
