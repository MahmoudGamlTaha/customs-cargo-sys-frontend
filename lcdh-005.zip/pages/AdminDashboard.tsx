
import React from 'react';
import Card from '../components/Card';
import { PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { MOCK_BI_DATA } from '../constants';
import { useTheme } from '../contexts/ThemeContext';
import { useLanguage, TranslationKey } from '../contexts/LanguageContext';
import { Wallet } from '../types';

const COLORS = ['#004AAD', '#007A3D', '#D4AF37', '#DC2626'];

interface AdminDashboardProps {
    memberCount: number;
    requestsCount: number;
    wallets: Wallet[];
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ memberCount, requestsCount, wallets }) => {
    const { theme } = useTheme();
    const { t } = useLanguage();
    const tickColor = theme === 'dark' ? '#A0AEC0' : '#374151';

    const totalWalletBalance = wallets.reduce((acc, wallet) => acc + wallet.balance, 0);

    const translatedMemberGrowth = MOCK_BI_DATA.memberGrowth.map(item => ({
        ...item,
        name: t(`data.months.${item.name}` as TranslationKey)
    }));
    const translatedRequestsByType = MOCK_BI_DATA.requestsByType.map(item => ({
        ...item,
        name: t(`data.requestTypes.${item.name}` as TranslationKey)
    }));

    return (
        <div>
            <h2 className="text-2xl sm:text-3xl font-bold mb-6 text-gray-800 dark:text-gray-200">{t('adminDashboard.title')}</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                <Card cardTitle={t('adminDashboard.cards.totalMembers')}><p className="text-3xl md:text-4xl font-bold text-brand-primary">{memberCount.toLocaleString()}</p></Card>
                <Card cardTitle={t('adminDashboard.cards.totalRequests')}><p className="text-3xl md:text-4xl font-bold text-brand-secondary">{requestsCount.toLocaleString()}</p></Card>
                <Card cardTitle={t('adminDashboard.cards.totalWalletFunds')}><p className="text-3xl md:text-4xl font-bold text-brand-accent">{totalWalletBalance.toLocaleString('en-US', {style: 'currency', currency: 'LYD'})}</p></Card>
                <Card cardTitle={t('adminDashboard.cards.activeDisputes')}><p className="text-3xl md:text-4xl font-bold text-red-600">15</p></Card>
            </div>

            <div className="flex flex-col lg:flex-row gap-6 mb-6">
                <Card cardTitle={t('adminDashboard.charts.memberGrowth')} className="flex-1">
                    <div style={{ width: '100%', height: 300 }}>
                        <ResponsiveContainer>
                            <LineChart data={translatedMemberGrowth} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                                <CartesianGrid strokeDasharray="3 3" stroke={theme === 'dark' ? '#4A5568' : '#E2E8F0'}/>
                                <XAxis dataKey="name" stroke={tickColor}/>
                                <YAxis stroke={tickColor}/>
                                <Tooltip
                                    contentStyle={{
                                        backgroundColor: theme === 'dark' ? '#2D3748' : '#FFFFFF',
                                        borderColor: theme === 'dark' ? '#4A5568' : '#E2E8F0'
                                    }}
                                />
                                <Legend wrapperStyle={{ color: tickColor }}/>
                                <Line type="monotone" dataKey="members" name={t('adminDashboard.charts.members')} stroke="#004AAD" strokeWidth={3} />
                            </LineChart>
                        </ResponsiveContainer>
                    </div>
                </Card>
                <Card cardTitle={t('adminDashboard.charts.requestsByType')} className="flex-1">
                    <div style={{ width: '100%', height: 300 }}>
                        <ResponsiveContainer>
                            <PieChart>
                                <Pie data={translatedRequestsByType} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} label={{ fill: tickColor }}>
                                    {translatedRequestsByType.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                    ))}
                                </Pie>
                                <Tooltip 
                                     contentStyle={{
                                        backgroundColor: theme === 'dark' ? '#2D3748' : '#FFFFFF',
                                        borderColor: theme === 'dark' ? '#4A5568' : '#E2E8F0'
                                    }}
                                />
                                <Legend wrapperStyle={{ color: tickColor }}/>
                            </PieChart>
                        </ResponsiveContainer>
                    </div>
                </Card>
            </div>

            <Card cardTitle={t('adminDashboard.chambersStats.title')}>
                <div className="overflow-x-auto">
                    <table className="w-full min-w-[600px]">
                        <thead>
                            <tr className="border-b-2 dark:border-gray-700">
                                <th className="py-3 px-4">{t('adminDashboard.chambersStats.chamber')}</th>
                                <th className="py-3 px-4">{t('adminDashboard.chambersStats.membersCount')}</th>
                                <th className="py-3 px-4">{t('adminDashboard.chambersStats.requests')}</th>
                                <th className="py-3 px-4">{t('adminDashboard.chambersStats.certificatesIssued')}</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">
                                <td className="py-3 px-4 font-semibold">{t('adminDashboard.chambersStats.tripoli')}</td>
                                <td className="py-3 px-4">850</td>
                                <td className="py-3 px-4">2,100</td>
                                <td className="py-3 px-4">1,500</td>
                            </tr>
                            <tr className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">
                                <td className="py-3 px-4 font-semibold">{t('adminDashboard.chambersStats.benghazi')}</td>
                                <td className="py-3 px-4">420</td>
                                <td className="py-3 px-4">1,150</td>
                                <td className="py-3 px-4">800</td>
                            </tr>
                            <tr className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">
                                <td className="py-3 px-4 font-semibold">{t('adminDashboard.chambersStats.misrata')}</td>
                                <td className="py-3 px-4">350</td>
                                <td className="py-3 px-4">800</td>
                                <td className="py-3 px-4">650</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export default AdminDashboard;
