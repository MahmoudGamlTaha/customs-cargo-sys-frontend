
import React, { useState, useMemo } from 'react';
import Card from '../../components/Card';
import BackButton from '../../components/BackButton';
import { User, UserRole, Wallet, Membership } from '../../types';
import CustomSelect from '../../components/CustomSelect';
import { useLanguage, TranslationKey } from '../../contexts/LanguageContext';

interface AdminUserManagementPageProps {
    users: User[];
    wallets: Wallet[];
    memberships: Membership[];
}

const getRoleClass = (role: UserRole) => {
    switch (role) {
        case UserRole.Admin: return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
        case UserRole.Staff: return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200';
        case UserRole.Member: return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
        default: return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200';
    }
};

const getStatusClass = (status: 'Active' | 'Suspended') => {
    return status === 'Active' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
};

const getMembershipStatusClass = (status: Membership['status'] | 'N/A') => {
    switch (status) {
        case 'approved': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
        case 'pending': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
        case 'rejected': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
        case 'on_hold': return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200';
        default: return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200';
    }
};


const AdminUserManagementPage: React.FC<AdminUserManagementPageProps> = ({ users, wallets, memberships }) => {
    const { t, language } = useLanguage();
    const [searchTerm, setSearchTerm] = useState('');
    const [roleFilter, setRoleFilter] = useState('all');
    const [statusFilter, setStatusFilter] = useState('all');

    const filteredUsers = useMemo(() => {
        return users.filter(user => {
            const name = language === 'ar' ? user.nameAr : user.nameEn;
            const matchesSearch = name.toLowerCase().includes(searchTerm.toLowerCase()) || user.email.toLowerCase().includes(searchTerm.toLowerCase());
            const matchesRole = roleFilter === 'all' || user.role === roleFilter;
            const matchesStatus = statusFilter === 'all' || user.status === statusFilter;
            return matchesSearch && matchesRole && matchesStatus;
        });
    }, [users, searchTerm, roleFilter, statusFilter, language]);
    
    const roleOptions = [
        { value: 'all', label: t('adminPages.users.filters.allRoles') },
        { value: UserRole.Member, label: t('roles.member') },
        { value: UserRole.Staff, label: t('roles.staff') },
        { value: UserRole.Admin, label: t('roles.admin') },
    ];

    const statusOptions = [
        { value: 'all', label: t('adminPages.users.filters.allStatuses') },
        { value: 'Active', label: t('adminPages.users.statuses.active') },
        { value: 'Suspended', label: t('adminPages.users.statuses.suspended') },
    ];

    const getUserWalletBalance = (userId: string) => {
        const wallet = wallets.find(w => w.userId === userId);
        return wallet ? wallet.balance : null;
    }

    const getUserMembershipStatus = (userId: string): Membership['status'] | 'N/A' => {
        const membership = memberships.find(m => m.userId === userId);
        return membership ? membership.status : 'N/A';
    }

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-3xl font-bold text-gray-800 dark:text-gray-200">{t('adminPages.users.title')}</h2>
                <BackButton />
            </div>

            <Card>
                <div className="p-4 border-b dark:border-gray-700 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <input
                        type="text"
                        placeholder={t('adminPages.users.searchPlaceholder')}
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full lg:col-span-2 p-2 border rounded-md bg-white text-gray-800 dark:bg-gray-600 dark:text-gray-200 dark:border-gray-500"
                    />
                    <CustomSelect options={roleOptions} value={roleFilter} onChange={setRoleFilter} />
                    <CustomSelect options={statusOptions} value={statusFilter} onChange={setStatusFilter} />
                </div>

                <div className="overflow-x-auto">
                    <table className="w-full min-w-[768px]">
                        <thead>
                            <tr className="border-b dark:border-gray-700">
                                <th className="py-3 px-4 whitespace-nowrap">{t('adminPages.users.table.name')}</th>
                                <th className="py-3 px-4 whitespace-nowrap">{t('adminPages.users.table.email')}</th>
                                <th className="py-3 px-4 whitespace-nowrap">{t('adminPages.users.table.company')}</th>
                                <th className="py-3 px-4 whitespace-nowrap">{t('adminPages.users.table.role')}</th>
                                <th className="py-3 px-4 whitespace-nowrap">{t('adminPages.users.table.status')}</th>
                                <th className="py-3 px-4 whitespace-nowrap">{t('adminPages.users.table.membershipStatus')}</th>
                                <th className="py-3 px-4 whitespace-nowrap">{t('adminPages.users.table.balance')}</th>
                                <th className="py-3 px-4 whitespace-nowrap">{t('adminPages.users.table.action')}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredUsers.length > 0 ? filteredUsers.map(user => {
                                const balance = getUserWalletBalance(user.id);
                                const membershipStatus = getUserMembershipStatus(user.id);
                                return (
                                <tr key={user.id} className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">
                                    <td className="py-3 px-4 font-semibold whitespace-nowrap">{language === 'ar' ? user.nameAr : user.nameEn}</td>
                                    <td className="py-3 px-4 whitespace-nowrap">{user.email}</td>
                                    <td className="py-3 px-4 whitespace-nowrap">{user.companyNameAr ? (language === 'ar' ? user.companyNameAr : user.companyNameEn) : 'N/A'}</td>
                                    <td className="py-3 px-4">
                                        <span className={`px-2 py-1 text-xs font-semibold rounded-full whitespace-nowrap ${getRoleClass(user.role)}`}>{t(`roles.${user.role}` as TranslationKey)}</span>
                                    </td>
                                    <td className="py-3 px-4">
                                        <span className={`px-2 py-1 text-xs font-semibold rounded-full whitespace-nowrap ${getStatusClass(user.status)}`}>{t(`adminPages.users.statuses.${user.status.toLowerCase()}` as TranslationKey)}</span>
                                    </td>
                                    <td className="py-3 px-4">
                                        <span className={`px-2 py-1 text-xs font-semibold rounded-full whitespace-nowrap ${getMembershipStatusClass(membershipStatus)}`}>
                                          {t(`membership.status.${membershipStatus === 'N/A' ? 'na' : membershipStatus}` as TranslationKey)}
                                        </span>
                                    </td>
                                    <td className="py-3 px-4 font-mono whitespace-nowrap">
                                        {balance !== null ? `${balance.toFixed(2)}` : 'N/A'}
                                    </td>
                                    <td className="py-3 px-4">
                                        <div className="flex gap-2">
                                            <button className="text-xs py-1 px-2 bg-blue-500 text-white rounded hover:bg-blue-600 whitespace-nowrap">{t('adminPages.users.actions.edit')}</button>
                                            <button className="text-xs py-1 px-2 bg-red-500 text-white rounded hover:bg-red-600 whitespace-nowrap">{t('adminPages.users.actions.suspend')}</button>
                                        </div>
                                    </td>
                                </tr>
                            )
                            }) : (
                                <tr><td colSpan={8} className="text-center py-8">{t('adminPages.users.noUsers')}</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export default AdminUserManagementPage;
