
import React, { useState } from 'react';
import Card from '../../components/Card';
import BackButton from '../../components/BackButton';
import { WalletTransaction, WalletTransactionType, User } from '../../types';
import { useLanguage, TranslationKey } from '../../contexts/LanguageContext';

interface StaffWalletPageProps {
    transactions: WalletTransaction[];
    onConfirmTopUp: (transactionId: string) => void;
    users: User[];
}

const StaffWalletPage: React.FC<StaffWalletPageProps> = ({ transactions, onConfirmTopUp, users }) => {
    const { t, language } = useLanguage();
    
    const topUpsToConfirm = transactions.filter(tx => tx.type === WalletTransactionType.Charge && tx.status === 'Pending');

    const getUserName = (userId: string) => {
        const user = users.find(u => u.id === userId);
        if (!user) return userId;
        return language === 'ar' ? user.nameAr : user.nameEn;
    };

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-3xl font-bold text-gray-800 dark:text-gray-200">{t('staffPages.wallet.title')}</h2>
                <BackButton />
            </div>

            <Card cardTitle={t('staffPages.wallet.cardTitle')}>
                <div className="overflow-x-auto">
                    <table className="w-full">
                        <thead>
                            <tr className="border-b dark:border-gray-700">
                                <th className="py-3 px-4">{t('staffPages.wallet.table.transactionId')}</th>
                                <th className="py-3 px-4">{t('staffPages.wallet.table.user')}</th>
                                <th className="py-3 px-4">{t('staffPages.wallet.table.amount')}</th>
                                <th className="py-3 px-4">{t('staffPages.wallet.table.date')}</th>
                                <th className="py-3 px-4">{t('staffPages.wallet.table.action')}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {topUpsToConfirm.length > 0 ? topUpsToConfirm.map(tx => (
                                <tr key={tx.id} className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">
                                    <td className="py-3 px-4 font-mono">{tx.id}</td>
                                    <td className="py-3 px-4 font-semibold">{getUserName(tx.userId)}</td>
                                    <td className="py-3 px-4 font-mono">{tx.amount.toFixed(2)}</td>
                                    <td className="py-3 px-4">{new Date(tx.date).toLocaleString()}</td>
                                    <td className="py-3 px-4">
                                        <button
                                            onClick={() => onConfirmTopUp(tx.id)}
                                            className="px-4 py-1 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700"
                                        >
                                            {t('staffPages.wallet.confirm')}
                                        </button>
                                    </td>
                                </tr>
                            )) : (
                                <tr><td colSpan={5} className="text-center py-8">{t('staffPages.wallet.noTopUps')}</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export default StaffWalletPage;
