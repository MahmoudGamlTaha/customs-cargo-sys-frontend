
import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Card from '../../components/Card';
import BackButton from '../../components/BackButton';
import { DocumentRequest, CertificateOfOriginData } from '../../types';
import { useLanguage, TranslationKey } from '../../contexts/LanguageContext';

interface StaffDocumentReviewPageProps {
    requests: DocumentRequest[];
    onReview: (requestId: string, decision: 'approved' | 'rejected' | 'on_hold') => void;
}

const StaffDocumentReviewPage: React.FC<StaffDocumentReviewPageProps> = ({ requests, onReview }) => {
    const { id } = useParams();
    const navigate = useNavigate();
    const { t } = useLanguage();
    const request = requests.find(req => req.id === id);

    const handleDecision = (decision: 'approved' | 'rejected' | 'on_hold') => {
        if (request) {
            onReview(request.id, decision);
            navigate('/staff/documents');
        }
    };

    if (!request) {
        return (
            <div>
                <BackButton />
                <Card><p className="p-8 text-center text-red-600">{t('review.membership.notFound')}</p></Card>
            </div>
        );
    }

    const OriginDetails: React.FC<{data: CertificateOfOriginData}> = ({ data }) => (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            {Object.entries(data).map(([key, value]) => (
                 <div key={key} className="p-2 bg-gray-50 dark:bg-gray-700 rounded-md">
                     <p className="font-semibold text-gray-600 dark:text-gray-400">{t(`documentServices.certOfOrigin.${key}` as TranslationKey)}</p>
                     <p className="text-gray-800 dark:text-gray-200 whitespace-pre-wrap">{value}</p>
                 </div>
            ))}
        </div>
    );
    
    const renderRequestDetails = () => {
        switch(request.serviceType) {
            case 'origin':
                return request.certificateData ? <OriginDetails data={request.certificateData} /> : <p>{t('review.document.noDetails')}</p>;
            case 'chamber_enrollment':
                return <p className="p-4 bg-blue-50 dark:bg-blue-900/30 border-l-4 border-blue-500 rounded-r-lg">{t('review.document.chamberEnrollmentNote')}</p>;
            case 'document_auth':
            case 'other':
                 return (
                    <div className="p-4 bg-yellow-50 dark:bg-yellow-900/30 border-l-4 border-yellow-500 rounded-r-lg">
                        <p>{t('review.document.otherNote')}</p>
                        <a href="#" className="text-brand-primary hover:underline font-semibold mt-2 inline-block">{t('review.document.viewAttachment')}</a>
                    </div>
                );
            default:
                return <p>{t('review.document.noDetails')}</p>;
        }
    }

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-3xl font-bold text-gray-800 dark:text-gray-200">{t('review.document.title')}</h2>
                <BackButton />
            </div>
            <Card cardTitle={`${t('review.document.detailsTitle')} #${id}`}>
                <div className="space-y-4 p-4">
                    <p><strong>{t('staffPages.documents.table.serviceType')}:</strong> {t(`data.serviceTypes.${request.serviceType}` as TranslationKey)}</p>
                    <p><strong>{t('adminPages.users.table.name')}:</strong> User ID: {request.userId}</p>
                    <p><strong>{t('review.membership.submissionDate')}:</strong> {request.date}</p>
                    <p><strong>{t('review.membership.currentStatus')}:</strong> {t(`status.${request.status}` as TranslationKey)}</p>
                    
                    <div className="pt-4 mt-4 border-t dark:border-gray-700">
                        <h4 className="font-bold mb-2">{t('review.document.requestContent')}:</h4>
                        {renderRequestDetails()}
                    </div>
                </div>
                <div className="flex justify-end gap-4 mt-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-b-xl">
                    <button onClick={() => handleDecision('rejected')} className="px-6 py-2 bg-red-600 text-white font-bold rounded-lg hover:bg-red-700">{t('review.actions.reject')}</button>
                    <button onClick={() => handleDecision('on_hold')} className="px-6 py-2 bg-purple-600 text-white font-bold rounded-lg hover:bg-purple-700">{t('review.actions.hold')}</button>
                    <button onClick={() => handleDecision('approved')} className="px-6 py-2 bg-green-600 text-white font-bold rounded-lg hover:bg-green-700">{t('review.actions.approve')}</button>
                </div>
            </Card>
        </div>
    );
};

export default StaffDocumentReviewPage;
