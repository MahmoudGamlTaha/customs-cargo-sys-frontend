
import React, { useState } from 'react';
import Card from '../../components/Card';
import BackButton from '../../components/BackButton';
import { MembershipRequest, RequestStatus } from '../../types';
import { useNavigate } from 'react-router-dom';
import { useLanguage, TranslationKey } from '../../contexts/LanguageContext';

const getStatusClass = (status: RequestStatus) => {
    switch (status) {
        case RequestStatus.New: return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
        case RequestStatus.InProgress: return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
        case RequestStatus.Completed: return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
        case RequestStatus.Rejected: return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
        case RequestStatus.OnHold: return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200';
        case RequestStatus.PendingPayment: return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200';
        default: return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200';
    }
};

interface StaffMembershipsPageProps {
    requests: MembershipRequest[];
}

const StaffMembershipsPage: React.FC<StaffMembershipsPageProps> = ({ requests }) => {
    const navigate = useNavigate();
    const { t, language } = useLanguage();
    const [filter, setFilter] = useState<RequestStatus | 'all'>('all');

    const filteredRequests = requests.filter(req => {
        if (filter === 'all') return true;
        return req.status === filter;
    });
    
    const filterOptions = [
        { value: 'all', label: t('staffPages.common.all') },
        { value: RequestStatus.New, label: t('status.New') },
        { value: RequestStatus.InProgress, label: t('status.InProgress') },
        { value: RequestStatus.OnHold, label: t('status.OnHold') },
        { value: RequestStatus.Completed, label: t('status.Completed') },
        { value: RequestStatus.Rejected, label: t('status.Rejected') },
        { value: RequestStatus.PendingPayment, label: t('status.PendingPayment') },
    ];

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-3xl font-bold text-gray-800 dark:text-gray-200">{t('staffPages.memberships.title')}</h2>
                <BackButton />
            </div>

            <Card>
                 <div className="p-4 border-b dark:border-gray-700 flex flex-wrap items-center gap-4">
                    <label htmlFor="statusFilter" className="font-semibold">{t('staffPages.common.filterByStatus')}:</label>
                    <select
                        id="statusFilter"
                        value={filter}
                        onChange={(e) => setFilter(e.target.value as RequestStatus | 'all')}
                        className="p-2 border rounded-md bg-white text-gray-800 dark:bg-gray-600 dark:text-gray-200 dark:border-gray-500"
                    >
                        {filterOptions.map(opt => (
                            <option key={opt.value} value={opt.value}>{opt.label}</option>
                        ))}
                    </select>
                </div>

                <div className="overflow-x-auto">
                    <table className="w-full">
                        <thead>
                            <tr className="border-b dark:border-gray-700">
                                <th className="py-3 px-4">{t('staffPages.memberships.table.requestId')}</th>
                                <th className="py-3 px-4">{t('staffPages.memberships.table.companyName')}</th>
                                <th className="py-3 px-4">{t('staffPages.memberships.table.applicant')}</th>
                                <th className="py-3 px-4">{t('staffPages.memberships.table.date')}</th>
                                <th className="py-3 px-4">{t('staffPages.memberships.table.status')}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredRequests.length > 0 ? filteredRequests.map(req => (
                                <tr
                                    key={req.id}
                                    className="border-b dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer"
                                    onClick={() => navigate(`/review/membership/${req.id}`)}
                                >
                                    <td className="py-3 px-4 font-mono">{req.id}</td>
                                    <td className="py-3 px-4 font-semibold">{language === 'ar' ? req.companyNameAr : req.companyNameEn}</td>
                                    <td className="py-3 px-4">{language === 'ar' ? req.applicantNameAr : req.applicantNameEn}</td>
                                    <td className="py-3 px-4">{req.date}</td>
                                    <td className="py-3 px-4">
                                        <span className={`px-2 py-1 text-sm font-semibold rounded-full ${getStatusClass(req.status)}`}>
                                            {t(`status.${req.status}` as TranslationKey)}
                                        </span>
                                    </td>
                                </tr>
                            )) : (
                                <tr><td colSpan={5} className="text-center py-8">{t('staffPages.common.noRequests')}</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export default StaffMembershipsPage;
