
import React, { useState, useEffect } from 'react';
import Card from '../components/Card';
import BackButton from '../components/BackButton';
import { MemberProfile, User } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { translateNameToEnglish, translateNameToArabic } from '../services/geminiService';

interface UserProfileProps {
    currentUser: User;
    profile: MemberProfile;
    onUpdateProfile: (userId: string, updates: Partial<User>) => Promise<void>;
}

const UserProfile: React.FC<UserProfileProps> = ({ currentUser, profile, onUpdateProfile }) => {
    const { t, language } = useLanguage();
    const [saveStatus, setSaveStatus] = useState('');
    const [passwordStatus, setPasswordStatus] = useState('');
    const [twoFAStatus, setTwoFAStatus] = useState('');

    const [formData, setFormData] = useState({
        fullName: '',
        email: '',
        phone: ''
    });

    useEffect(() => {
        if (currentUser) {
            setFormData({
                fullName: language === 'ar' ? currentUser.nameAr : currentUser.nameEn,
                email: currentUser.email,
                phone: currentUser.phone,
            });
        }
    }, [currentUser, language]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({...prev, [name]: value}));
    }

    const handleAction = (setStatus: React.Dispatch<React.SetStateAction<string>>) => {
        setStatus('loading');
        setTimeout(() => {
            setStatus('done');
            setTimeout(() => {
                setStatus('');
            }, 2000);
        }, 1000);
    };
    
    const handleSaveChanges = async (e: React.FormEvent) => {
        e.preventDefault();
        setSaveStatus('loading');
        try {
            const newName = formData.fullName;
            let nameAr = currentUser.nameAr;
            let nameEn = currentUser.nameEn;

            if (language === 'ar') {
                // User is in Arabic UI, so they are editing the Arabic name.
                nameAr = newName;
                nameEn = await translateNameToEnglish(newName);
            } else {
                // User is in English UI, so they are editing the English name.
                nameEn = newName;
                nameAr = await translateNameToArabic(newName);
            }

            await onUpdateProfile(currentUser.id, {
                // While fullName in the form is updated, nameAr/nameEn are the canonical sources.
                // We update fullName on the user object to the new primary name based on UI language.
                fullName: newName,
                nameAr,
                nameEn,
                email: formData.email,
                phone: formData.phone,
            });
            setSaveStatus('done');
        } catch (error) {
            console.error("Failed to save profile changes", error);
            // Optionally handle error state
        } finally {
            setTimeout(() => setSaveStatus(''), 2000);
        }
    };
    
    const handleChangePassword = () => handleAction(setPasswordStatus);
    const handleToggle2FA = () => handleAction(setTwoFAStatus);
    
    const getButtonText = (status: string, initialKey: any, loadingKey: any, doneKey: any) => {
        if (status === 'loading') return t(loadingKey);
        if (status === 'done') return t(doneKey);
        return t(initialKey);
    };

    const InputField: React.FC<{ label: string, id: string, type?: string, value: string, disabled?: boolean, onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void }> = ({ label, id, type = "text", value, disabled, onChange }) => (
        <div>
            <label htmlFor={id} className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{label}</label>
            <input 
              type={type} 
              id={id} 
              name={id}
              value={value} 
              onChange={onChange}
              disabled={disabled} 
              className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200 focus:ring-brand-primary focus:border-brand-primary disabled:bg-gray-200 dark:disabled:bg-gray-600" />
        </div>
    );

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-3xl font-bold text-gray-800 dark:text-gray-200">{t('userProfile.title')}</h2>
                <BackButton />
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                    <Card cardTitle={t('userProfile.accountInfo.title')}>
                        <form onSubmit={handleSaveChanges} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                           <InputField label={t('userProfile.accountInfo.fullName')} id="fullName" value={formData.fullName} onChange={handleChange} />
                           <InputField label={t('userProfile.accountInfo.email')} id="email" type="email" value={formData.email} onChange={handleChange}/>
                           <InputField label={t('userProfile.accountInfo.phone')} id="phone" type="tel" value={formData.phone} onChange={handleChange}/>
                           <InputField label={t('userProfile.accountInfo.company')} id="company" value={language === 'ar' ? profile.companyNameAr : profile.companyNameEn} disabled />
                           <div className="md:col-span-2 flex justify-end">
                                <button type="submit" className="px-6 py-2 bg-brand-primary text-white font-bold rounded-lg hover:bg-blue-800 w-36 disabled:opacity-70" disabled={!!saveStatus}>
                                    {getButtonText(saveStatus, 'userProfile.accountInfo.saveButton', 'userProfile.accountInfo.savingButton', 'userProfile.accountInfo.savedButton')}
                                </button>
                           </div>
                        </form>
                    </Card>
                     <Card cardTitle={t('userProfile.security.title')}>
                        <div className="space-y-4">
                            <div>
                                <h4 className="font-semibold">{t('userProfile.security.changePassword')}</h4>
                                <button onClick={handleChangePassword} className="text-sm text-brand-primary hover:underline disabled:text-gray-500" disabled={!!passwordStatus}>
                                    {getButtonText(passwordStatus, 'userProfile.security.changeButton', 'userProfile.security.loading', 'userProfile.security.done')}
                                </button>
                            </div>
                            <div>
                                <h4 className="font-semibold">{t('userProfile.security.twoFa')}</h4>
                                <div className="flex items-center">
                                    <p className="text-sm text-gray-600 dark:text-gray-400 ltr:mr-4 rtl:ml-4">{t('userProfile.security.status')}: <span className="font-bold text-green-600 dark:text-green-400">{t('userProfile.security.status_active')}</span></p>
                                    <button onClick={handleToggle2FA} className="text-sm text-red-600 hover:underline disabled:text-gray-500" disabled={!!twoFAStatus}>
                                        {getButtonText(twoFAStatus, 'userProfile.security.disableButton', 'userProfile.security.loading', 'userProfile.security.done')}
                                    </button>
                                </div>
                            </div>
                        </div>
                    </Card>
                </div>
                <div>
                    <Card cardTitle={t('userProfile.history.title')}>
                        <ul className="space-y-3">
                            <li className="text-sm p-2 bg-gray-50 dark:bg-gray-700 rounded">{t('userProfile.history.item1')}</li>
                            <li className="text-sm p-2 bg-gray-50 dark:bg-gray-700 rounded">{t('userProfile.history.item2')}</li>
                            <li className="text-sm p-2 bg-gray-50 dark:bg-gray-700 rounded">{t('userProfile.history.item3')}</li>
                            <li className="text-sm p-2 bg-gray-50 dark:bg-gray-700 rounded">{t('userProfile.history.item4')}</li>
                        </ul>
                    </Card>
                </div>
            </div>
        </div>
    );
};

export default UserProfile;
