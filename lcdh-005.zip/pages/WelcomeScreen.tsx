import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { OfficialLogoIcon, UsersIcon, DocumentIcon, PaymentIcon, EventsIcon } from '../components/icons';

const AnimatedPlatformDemo: React.FC = () => {
    const iconBaseClasses = "absolute w-12 h-12 sm:w-16 sm:h-16 p-3 sm:p-4 rounded-full bg-white/80 dark:bg-gray-800/80 shadow-lg backdrop-blur-sm border border-white/20 dark:border-gray-700/50 flex items-center justify-center transition-transform hover:scale-110";

    return (
        <div className="relative w-full aspect-[4/3] sm:aspect-video max-w-lg mx-auto my-8">
            <div className="absolute inset-0 bg-gradient-to-br from-brand-primary to-brand-secondary rounded-3xl shadow-2xl transform -rotate-3"></div>
            <div className="relative w-full h-full bg-gray-200/50 dark:bg-gray-900/50 rounded-2xl shadow-inner backdrop-blur-lg overflow-hidden">
                {/* Floating Icons */}
                <div className={`${iconBaseClasses} top-[10%] left-[15%] text-blue-500`}><UsersIcon /></div>
                <div className={`${iconBaseClasses} top-[20%] right-[10%] text-green-500`}><DocumentIcon /></div>
                <div className={`${iconBaseClasses} bottom-[25%] left-[25%] text-yellow-500`}><PaymentIcon /></div>
                <div className={`${iconBaseClasses} bottom-[15%] right-[20%] text-purple-500`}><EventsIcon /></div>

                {/* Animated Cursor */}
                <div className="animated-cursor"></div>
            </div>
        </div>
    );
};


const WelcomeScreen: React.FC = () => {
    const [isAgreed, setIsAgreed] = useState(false);
    const navigate = useNavigate();
    const { t, language, setLanguage } = useLanguage();

    const handleContinue = () => {
        if (isAgreed) {
            navigate('/login');
        }
    };

    const toggleLanguage = () => {
      const newLang = language === 'ar' ? 'en' : 'ar';
      setLanguage(newLang);
    };

    return (
        <div dir={language === 'ar' ? 'rtl' : 'ltr'} className="min-h-screen bg-gray-100 dark:bg-gray-900 flex flex-col items-center justify-center p-4 text-gray-800 dark:text-gray-200">
            <div className="absolute top-4 ltr:right-4 rtl:left-4">
                 <button
                  onClick={toggleLanguage}
                  className="font-bold text-lg text-brand-primary hover:text-blue-600 dark:text-blue-300 dark:hover:text-blue-400 px-3 py-1 rounded-md"
                  aria-label={t('header.toggleLanguage')}
                >
                  {language === 'ar' ? 'EN' : 'AR'}
                </button>
            </div>
            
            <div className="w-full max-w-3xl text-center">
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-2">
                    <OfficialLogoIcon className="h-16 sm:h-20" />
                    <h1 className="text-2xl sm:text-3xl font-bold text-brand-primary dark:text-blue-300">{t('welcomeScreen.title')}</h1>
                </div>

                <AnimatedPlatformDemo />

                <div className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl p-6 sm:p-8 max-w-2xl mx-auto">
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-6 leading-relaxed">
                        {t('welcomeScreen.disclaimer')}
                    </p>
                    
                    <div className="flex items-center justify-center mb-6">
                        <input
                            type="checkbox"
                            id="agree"
                            checked={isAgreed}
                            onChange={(e) => setIsAgreed(e.target.checked)}
                            className="h-4 w-4 rounded border-gray-300 text-brand-primary focus:ring-brand-primary"
                        />
                        <label htmlFor="agree" className="ltr:ml-2 rtl:mr-2 block text-sm text-gray-900 dark:text-gray-300">
                           {t('welcomeScreen.agreeCheckbox')}
                        </label>
                    </div>

                    {isAgreed && (
                        <button
                            onClick={handleContinue}
                            className="w-full bg-brand-primary hover:bg-blue-800 text-white font-bold py-3 px-6 rounded-lg focus:outline-none focus:shadow-outline transition-opacity duration-300"
                        >
                           {t('welcomeScreen.continueButton')}
                        </button>
                    )}
                </div>

            </div>
        </div>
    );
};

export default WelcomeScreen;