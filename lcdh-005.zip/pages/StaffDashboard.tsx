import React from 'react';
import Card from '../components/Card';
import { UsersIcon, DocumentIcon, PaymentIcon, ReportsIcon } from '../components/icons';
import { Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';

interface StaffDashboardProps {
    membershipRequestsCount: number;
    documentRequestsCount: number;
    paymentsToConfirmCount: number;
}

const StatCard: React.FC<{ title: string, count: number, linkTo: string, icon: React.ReactNode, cta: string }> = ({ title, count, linkTo, icon, cta }) => (
    <Link to={linkTo} className="block h-full">
        <Card className="h-full">
            <div className="flex flex-col items-center justify-center text-center h-full p-4">
                <div className="p-3 sm:p-4 bg-brand-primary/10 dark:bg-brand-primary/20 text-brand-primary dark:text-blue-300 rounded-full mb-4">
                    {icon}
                </div>
                <h4 className="text-base sm:text-lg font-semibold text-gray-700 dark:text-gray-300">{title}</h4>
                <p className="text-3xl sm:text-4xl font-bold mt-2 text-gray-900 dark:text-gray-100">{count}</p>
                <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">{cta}</p>
            </div>
        </Card>
    </Link>
);


const StaffDashboard: React.FC<StaffDashboardProps> = ({ membershipRequestsCount, documentRequestsCount, paymentsToConfirmCount }) => {
  const { t } = useLanguage();
  return (
    <div>
      <h2 className="text-2xl sm:text-3xl font-bold mb-2 text-gray-800 dark:text-gray-200">{t('staffDashboard.title')}</h2>
      <p className="mb-6 text-base sm:text-lg text-gray-600 dark:text-gray-400">{t('staffDashboard.subtitle')}</p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <StatCard 
            title={t('staffDashboard.cards.membershipRequests')}
            count={membershipRequestsCount}
            linkTo="/staff/memberships"
            icon={<UsersIcon />}
            cta={t('staffDashboard.cards.cta')}
        />
        <StatCard 
            title={t('staffDashboard.cards.documentRequests')}
            count={documentRequestsCount}
            linkTo="/staff/documents"
            icon={<DocumentIcon />}
            cta={t('staffDashboard.cards.cta')}
        />
        <StatCard 
            title={t('staffDashboard.cards.pendingTopUps')}
            count={paymentsToConfirmCount}
            linkTo="/staff/wallet"
            icon={<PaymentIcon />}
            cta={t('staffDashboard.cards.cta')}
        />
      </div>

       <div className="mt-8">
            <Card cardTitle={t('staffDashboard.quickActions.title')}>
                <div className="flex flex-col sm:flex-row flex-wrap gap-4">
                     <Link to="/bi-reports" className="flex items-center gap-2 p-3 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600">
                        <ReportsIcon/>
                        <span>{t('staffDashboard.quickActions.viewReports')}</span>
                    </Link>
                     <Link to="/admin/users" className="flex items-center gap-2 p-3 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600">
                        <UsersIcon/>
                        <span>{t('staffDashboard.quickActions.findMember')}</span>
                    </Link>
                </div>
            </Card>
        </div>
    </div>
  );
};

export default StaffDashboard;