
// This enum defines the roles a user can have within the system.
export enum UserRole {
  Member = 'member',
  Staff = 'staff',
  Admin = 'admin',
  Arbitrator = 'arbitrator'
}

// User collection
export interface User {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  role: UserRole;
  chamberId: string; // Reference to chambers collection
  membershipId: string; // Reference to memberships collection
  createdAt: string; // ISO 8601 timestamp
  status: 'Active' | 'Suspended';
  // for UI compatibility
  nameAr: string;
  nameEn: string;
  companyNameAr: string;
  companyNameEn: string;
}

// Membership collection
export interface Membership {
  id: string;
  userId: string; // Reference to users collection
  status: 'pending' | 'approved' | 'rejected' | 'on_hold';
  membershipNumber: string; // Assigned on approval
  expiryDate: string; // ISO 8601 timestamp
  createdAt: string; // ISO 8601 timestamp
}

export type CertificateType = 'origin' | 'document_auth' | 'other' | 'chamber_enrollment';
export const CertificateType = {
  Origin: 'origin' as CertificateType,
  DocumentAuth: 'document_auth' as CertificateType,
  Other: 'other' as CertificateType,
  ChamberEnrollment: 'chamber_enrollment' as CertificateType,
};


// Certificate collection
export interface Certificate {
  id: string;
  userId: string; // Reference to users collection
  certificateType: CertificateType;
  status: 'draft' | 'submitted' | 'approved' | 'rejected' | 'on_hold';
  issueDate: string | null; // ISO 8601 timestamp, null until approved
  documentUrl: string; // URL to the generated PDF/document
  notes: string;
  createdAt: string; // ISO 8601 timestamp
}

export type PaymentType = 'membership_fee' | 'certificate_fee' | 'event_fee';
export const PaymentType = {
  MembershipFee: 'membership_fee' as PaymentType,
  CertificateFee: 'certificate_fee' as PaymentType,
  EventFee: 'event_fee' as PaymentType
};

// Payment collection
export interface Payment {
  id: string;
  userId: string; // Reference to users collection
  paymentType: PaymentType;
  amount: number;
  status: 'pending' | 'paid' | 'failed';
  paymentDate: string; // ISO 8601 timestamp
  method: string; // e.g., 'wallet', 'credit_card'
  transactionId: string;
}

// Event collection
export interface Event {
  id: string;
  title: string;
  description: string;
  location: string;
  startDate: string; // ISO 8601 timestamp
  endDate: string; // ISO 8601 timestamp
  fee: number;
  participants: string[]; // Array of user IDs
}

// Dispute collection
export interface Dispute {
  id: string;
  submittedBy: string; // Reference to users collection
  againstUser: string; // Reference to users collection
  arbitratorId?: string; // Reference to an arbitrator user
  status: 'open' | 'in_review' | 'resolved' | 'closed';
  details: string;
  submittedAt: string; // ISO 8601 timestamp
  resolutionNotes: string;
}

// Chamber collection
export interface Chamber {
  id: string;
  name: string;
  location: string;
  contactEmail: string;
  createdAt: string; // ISO 8601 timestamp
}

// Wallet collection
export interface Wallet {
  id: string;
  userId: string; // Reference to users collection
  balance: number;
  lastUpdated: string; // ISO 8601 timestamp
}

export type WalletTransactionType = 'charge' | 'payment' | 'transfer_out' | 'transfer_in';

export const WalletTransactionType = {
  Charge: 'charge' as WalletTransactionType,
  Payment: 'payment' as WalletTransactionType,
  TransferOut: 'transfer_out' as WalletTransactionType,
  TransferIn: 'transfer_in' as WalletTransactionType,
}

// Wallet Transaction collection
export interface WalletTransaction {
  id: string;
  userId: string; // Reference to users collection
  type: WalletTransactionType;
  amount: number; // Always positive
  relatedUserId?: string; // Reference to users collection (for transfers)
  referenceId?: string; // Optional link to a service (paymentId, etc.)
  description: string;
  date: string; // ISO 8601 timestamp
  status: 'Completed' | 'Pending' | 'Failed';
}

// Support Ticket Collection
export interface SupportTicket {
  id: string;
  userId: string;
  title: string;
  status: 'open' | 'in_review' | 'solved';
  createdAt: string;
}


// --- LEGACY TYPES FOR UI COMPATIBILITY ---

export enum InvoiceStatus {
  Paid = 'Paid',
  Pending = 'Pending',
  RequiresConfirmation = 'RequiresConfirmation',
}

export enum RequestStatus {
  New = 'New',
  InProgress = 'InProgress',
  Completed = 'Completed',
  Rejected = 'Rejected',
  OnHold = 'OnHold',
  PendingPayment = 'PendingPayment',
}

export interface MemberProfile {
  id: string;
  nameAr: string;
  nameEn: string;
  companyNameAr: string;
  companyNameEn: string;
  membershipStatus: 'Active' | 'Inactive' | 'Pending' | 'rejected';
  expiryDate: string;
  commercialRegistryNo?: string;
  membershipGrade?: string;
  title?: string;
  chamberName?: string;
}

export interface CertificateOfOriginData {
    consignee: string;
    transportDetails: string;
    marksAndNumbers: string;
    numberOfPackages: string;
    goodsDescription: string;
    grossWeight: string;
    netWeight: string;
    invoiceNumber: string;
    invoiceDate: string;
}

export interface DocumentRequest {
  id: string;
  serviceType: string;
  date: string;
  status: RequestStatus;
  fee: number;
  certificateData?: CertificateOfOriginData;
  userId: string;
}

// Represents a membership application as viewed by staff
export interface MembershipRequest {
    id: string; // membership id
    userId: string;
    date: string; // membership createdAt
    status: RequestStatus;
    companyNameAr: string;
    companyNameEn: string;
    applicantNameAr: string;
    applicantNameEn: string;
}

export interface LegacyEvent extends Event {
  isRegistered: boolean;
}

export interface Invoice {
  id: string;
  description: string;
  amount: number;
  status: 'paid' | InvoiceStatus;
  requestId: string;
  requestType: PaymentType | 'membership' | 'document' | 'event' | 'top-up';
  paymentDate?: string;
}

// Kept for elearning page compatibility
export interface Course {
  id: string;
  title: string;
  instructor: string;
  duration: string;
  progress: number;
}
